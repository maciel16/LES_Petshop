<?php
require_once "../config.php";
require_once "../login.php";
$note = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    try {
        $sql = "SELECT cliente_id
        FROM cliente
        WHERE cliente_id = '$_POST[cliente_id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();

        $linha = $stmt->fetch(PDO::FETCH_ASSOC);

        $cliente_id = "$linha[cliente_id]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
    if ($cliente_id <> $_POST["cliente_id"]) {
        $note = "*Código de Cliente não encontrado*";
    } else {
        $sql = "INSERT INTO animal  (nome,tipo,raca,peso,idade,sexo)
        VALUES('$_POST[nome]','$_POST[tipo]','$_POST[raca]','$_POST[peso]','$_POST[idade]','$_POST[sexo]')";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        if ($stmt->error) {
            echo "Error!" . $stmt->error;
            exit();
        } else {

            $sql2 = "SELECT a.animal_id
            FROM animal a
            ORDER BY animal_id DESC
            LIMIT 1";
            $stmt = $conn->prepare($sql2);
            $stmt->execute();
            $linha = $stmt->fetch(PDO::FETCH_ASSOC);
            $animal_id = "$linha[animal_id]";
            if ($stmt->error) {
                echo "Error!" . $stmt->error;
                exit();
            } else {

                $sql3 = "INSERT INTO cliente_animal (cliente_id,animal_id)
                VALUES('$_POST[cliente_id]','$animal_id')";
                $stmt = $conn->prepare($sql3);
                $stmt->execute();
                if ($stmt->error) {
                    echo "Error!" . $stmt->error;
                    exit();
                } else {
                    header("location: animais.php");
                    exit();
                }
            }
        }
    }
}

?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

        <div class="">
            <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                    <div class="navbar-header">
                        <button type="button" id="sidebarCollapse" class="navbar-btn">
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>

                    <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-5 col-md-5 col-sm-5">
                        <div id="" class="col-lg-12 col-md-12 col-sm-12">
                            <a href="/petshop/principal.php">| Início</a>
                            <a href="animais.php">> Animais</a>
                            <a>> Cadastrar Animal</a>
                        </div>
                    </div>
                </div>
            </nav>

        </div>

        <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
            <h2>Adicionar Animais</h2>

        </div>

        <div class="block col-lg-12 col-md-12 col-sm-12">
            <br>
            <div class="table">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div id="tabel">
                                <div class="card" style="margin-top:20px;">
                                    <div class="card-body">
                                        <div class="page-header">
                                            <h2>Cadastro Animais</h2>
                                        </div>
                                        <p>Cadastro de Animal</p>
                                        <p>Campo Obrigatório(*)</p>
                                        <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post">
                                            <h5 style="color:red">
                                                <?php
                                                echo $note;
                                                ?>
                                            </h5>

                                            <div class="form-group">
                                                <label>Código Identificação do Cliente*</label>
                                                <input type="text" name="cliente_id" class="form-control" required placeholder="">
                                            </div>

                                            <div class="form-group">
                                                <label>Nome*</label>
                                                <input type="text" name="nome" class="form-control" required placeholder="">
                                            </div>

                                            <fieldset class="form-group">
                                                <label for="message">Tipo de Animal</label>
                                                <br>
                                                <select id="tipo" name="tipo" required class="form-control" required>
                                                    <option value="Gato">Gato</option>
                                                    <option value="Cachorro">Cachorro</option>
                                                </select>
                                            </fieldset>

                                            <div class="form-group">
                                                <label>Raça*</label>
                                                <input type="text" name="raca" class="form-control" required placeholder="">
                                            </div>

                                            <div class="form-group">
                                                <label>Peso em Quilogramas(Kg)*</label>
                                                <input type="text" name="peso" class="form-control" required placeholder="">
                                            </div>

                                            <div class="form-group">
                                                <label>Idade em Anos*</label>
                                                <input type="text" name="idade" class="form-control" required placeholder="">
                                            </div>

                                            <fieldset class="form-group">
                                                <label for="message">Sexo</label>
                                                <br>
                                                <select id="tipo" name="sexo" required class="form-control" required>
                                                    <option value="Macho">Macho</option>
                                                    <option value="Fêmea">Fêmea</option>
                                                </select>
                                            </fieldset>

                                            <div id="btn">
                                                <input type="submit" class="btn btn-success" value="Cadastrar">
                                                <a href="animais.php" class="btn btn-cancel">Voltar</a>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br>
                </div>
                <br>
            </div>
            <br>
        </div>


        <!-- Footer Configuration, follow the link to modify-->
        <?php require_once "../components/footer.php" ?>