<?php
require_once "../config.php";
require_once "../login.php";
if (isset($_GET['animal_id'])) {

    try {
        $sql = $sql = "SELECT CONCAT(c.primeiro_nome,' ',c.ultimo_nome) dono, a.animal_id, a.nome, a.tipo, a.raca, a.peso,
        a.idade, a.sexo, a.reg_date, a.last_update 
        FROM animal a
        INNER JOIN cliente_animal ca ON ca.animal_id = a.animal_id
        INNER JOIN cliente c ON ca.cliente_id = c.cliente_id
            WHERE a.animal_id = '$_GET[animal_id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $animal_id = "$linha[animal_id]";
        $dono = "$linha[dono]";
        $nome = "$linha[nome]";
        $tipo = "$linha[tipo]";
        $raca = "$linha[raca]";
        $peso = "$linha[peso]";
        $idade = "$linha[idade]";
        $sexo = "$linha[sexo]";
        $reg_date = "$linha[reg_date]";
        $last_update = "$linha[last_update]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "DELETE 
            FROM cliente_animal
            WHERE animal_id = '$_GET[animal_id]'";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    if ($stmt->error) {
        echo "Error!" . $stmt->error;
        exit();
    } else {
        $sql2 = "DELETE 
            FROM animal
            WHERE animal_id = '$_GET[animal_id]'";
        $stmt = $conn->prepare($sql2);
        $stmt->execute();
        if ($stmt->error) {
            echo "Error!" . $stmt->error;
            exit();
        } else {
            header("location: animais.php");
            exit();
        }
    }
    $conn = null;
}

?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

        <div class="">
            <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                    <div class="navbar-header">
                        <button type="button" id="sidebarCollapse" class="navbar-btn">
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>

                    <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-5 col-md-5 col-sm-5">
                        <div id="" class="col-lg-12 col-md-12 col-sm-12">
                            <a href="/petshop/principal.php">| Início</a>
                            <a href="animais.php">> Animais</a>
                            <a>> Remover Animal</a>
                        </div>
                    </div>
                </div>
            </nav>

        </div>

        <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
            <h2>Remover Cadastro de Animais</h2>

        </div>

        <div class="block col-lg-12 col-md-12 col-sm-12">
            <br>
            <div class="table">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div id="tabel">
                                <div class="card" style="margin-top:20px;">
                                    <div class="card-body">
                                        <div class="page-header">
                                            <h2>Excluir</h2>
                                        </div>
                                        <h1>Deseja realmente remover os dados abaixo?</h1>
                                        <form action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post">
                                            <div class="form-group">
                                                <h4>Código de Identificação do Animal</h4>
                                                <p class="form-control-static"><?php echo $animal_id; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Nome</h4>
                                                <p class="form-control-static"><?php echo $nome; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Dono</h4>
                                                <p class="form-control-static"><?php echo $dono; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Tipo de Animal</h4>
                                                <p class="form-control-static"><?php echo $tipo; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Peso do Animal em Quilogramas(Kg)</h4>
                                                <p class="form-control-static"><?php echo $peso; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Idade em Anos</h4>
                                                <p class="form-control-static"><?php echo $idade; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Sexo</h4>
                                                <p class="form-control-static"><?php echo $sexo; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Data de Registro</h4>
                                                <p class="form-control-static"><?php echo $reg_date; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Ultima Atualização</h4>
                                                <p class="form-control-static"><?php echo $last_update; ?></p>
                                            </div>
                                            <div id="btn" class="col-lg-12 col-md-12 col-sm-12">
                                                <input type="submit" class="btn btn-cancel" value="Remover">
                                                <a href="animais.php" class="btn btn-primary">Voltar</a>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br>
                </div>
                <br>
            </div>
            <br>
        </div>

        <!-- Footer Configuration, follow the link to modify-->
        <?php require_once "../components/footer.php" ?>