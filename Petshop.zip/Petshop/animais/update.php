<?php
require_once "../config.php";
require_once "../login.php";
if (isset($_GET['animal_id'])) {

    try {
        $sql = $sql = "SELECT CONCAT(c.primeiro_nome,' ',c.ultimo_nome) dono, a.animal_id, a.nome, a.tipo, a.raca, a.peso,
        a.idade, a.sexo, a.reg_date, a.last_update 
        FROM animal a
        INNER JOIN cliente_animal ca ON ca.animal_id = a.animal_id
        INNER JOIN cliente c ON ca.cliente_id = c.cliente_id
            WHERE a.animal_id = '$_GET[animal_id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $animal_id = "$linha[animal_id]";
        $dono = "$linha[dono]";
        $nome = "$linha[nome]";
        $tipo = "$linha[tipo]";
        $raca = "$linha[raca]";
        $peso = "$linha[peso]";
        $idade = "$linha[idade]";
        $sexo = "$linha[sexo]";
        $reg_date = "$linha[reg_date]";
        $last_update = "$linha[last_update]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "UPDATE animal SET idade = '$_POST[idade]', peso = '$_POST[peso]' WHERE animal_id = '$_GET[animal_id]'";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    if ($stmt->error) {
        echo "Error!" . $stmt->error;
        exit();
    } else {
        header("location: update.php?animal_id=$animal_id");
        exit();
    }

    $conn = null;
}
$conn = null;
?>

<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

        <div class="">
            <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                    <div class="navbar-header">
                        <button type="button" id="sidebarCollapse" class="navbar-btn">
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>

                    <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-5 col-md-5 col-sm-5">
                        <div id="" class="col-lg-12 col-md-12 col-sm-12">
                            <a href="/petshop/principal.php">| Início</a>
                            <a href="animais.php">> Animais</a>
                            <a>> Alterar Cadastro Animal</a>
                        </div>
                    </div>
                </div>
            </nav>

        </div>

        <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
            <h2>Alterar Animais</h2>

        </div>

        <div class="block col-lg-12 col-md-12 col-sm-12">
            <br>
            <div class="table">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div id="tabel">
                                <div class="card" style="margin-top:20px;">
                                    <div class="card-body">
                                        <div class="page-header">
                                            <h2>Editar</h2>
                                        </div>
                                        <p>Preencha os novos dados e clique em atualizar para finalizar a edição.</p>
                                        <form action="<?php echo $_SERVER["REQUEST_URI"] ?>" method="post">
                                            <p>Campo Obrigatório(*)</p>
                                            <div class="form-group">
                                                <label>Código de Identificação do Animal*</label>
                                                <input type="text" name="animal_id" class="form-control" readonly="true" required placeholder="" value="<?php echo $animal_id; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label>Nome*</label>
                                                <input type="text" name="nome" class="form-control" readonly="true" required placeholder="" value="<?php echo $nome; ?>">
                                            </div>

                                            <div class="form-group">
                                                <label>Dono*</label>
                                                <input type="text" name="dono" class="form-control" readonly="true" required placeholder="" value="<?php echo $dono; ?>">
                                            </div>

                                            <div class="form-group">
                                                <label>Tipo de Animal*</label>
                                                <input type="text" name="tipo" class="form-control" readonly="true" required placeholder="" value="<?php echo $tipo; ?>">
                                            </div>


                                            <div class="form-group">
                                                <label>Peso do Animal em Quilogramas(Kg)*</label>
                                                <input type="number" name="peso" class="form-control" required placeholder="" value="<?php echo $peso; ?>">
                                            </div>

                                            <div class="form-group">
                                                <label>Idade do Animal*</label>
                                                <input type="number" name="idade" class="form-control" required placeholder="" value="<?php echo $idade; ?>">
                                            </div>

                                            <div class="form-group">
                                                <label>Sexo do Animal*</label>
                                                <input type="text" name="sexo" class="form-control" readonly="true" required placeholder="" value="<?php echo $sexo; ?>">
                                            </div>

                                            <div class="form-group">
                                                <label>Data de Registro*</label>
                                                <input type="text" name="reg_date" class="form-control" readonly="true" required value="<?php echo $reg_date; ?>">
                                            </div>

                                            <div class="form-group">
                                                <label>Ultima Atualização*</label>
                                                <input type="text" name="last_update" class="form-control" readonly="true" required value="<?php echo $last_update; ?>">
                                            </div>
                                            <div id="btn">
                                                <input type="submit" class="btn btn-primary" value="Atualizar">
                                                <a href="animais.php" class="btn btn-cancel">Voltar</a>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br>
                </div>
                <br>
            </div>
            <br>
            <!-- Footer Configuration, follow the link to modify-->
            <?php require_once "../components/footer.php" ?>