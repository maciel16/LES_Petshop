<?php
require_once "../config.php";
require_once "../login.php";
$note = "";
(isset($_SESSION['atendimento_id']));
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $sql = "SELECT servico_id
                FROM servico s
                WHERE servico_id = '$_POST[servico_id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $servico_id = "$linha[servico_id]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
    if ($servico_id <> "$_POST[servico_id]") {
        $note = "*O Código do serviço não foi encontrado!*";
    } else {
        $sql = "INSERT INTO servico_atendimento(servico_id,atendimento_id,valor)
                VALUES($_POST[servico_id],$_POST[atendimento_id],(SELECT s.preco 
                FROM servico s
                WHERE s.servico_id = '$_POST[servico_id]'))";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        if ($stmt->error) {
            echo "Error!" . $stmt->error;
            exit();
        } else {
            header("location: atendimento_servicos.php?atendimento_id=$_POST[atendimento_id]");

            exit();
        }
    }
}
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

        <div class="">
            <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                    <div class="navbar-header">
                        <button type="button" id="sidebarCollapse" class="navbar-btn">
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>

                    <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-8 col-md-8 col-sm-8">
                        <div id="" class="col-lg-12 col-md-12 col-sm-12">
                            <a href="/petshop/atendimentos/atendimentos.php">| Atendimentos</a>
                            <a>> Serviços Prestados</a>
                            <a>> Adicionar Serviço Prestado</a>
                        </div>
                    </div>
                </div>
            </nav>

        </div>

        <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
            <h2>Adicionar Serviço Prestado</h2>

        </div>

        <div class="block col-lg-12 col-md-12 col-sm-12">
            <br>
            <div class="table">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div id="tabel">
                                <div class="card" style="margin-top:20px;">
                                    <div class="card-body">
                                        <div class="page-header">
                                            <h2>Adicionar Serviço Prestado</h2>
                                        </div>
                                        <p>Cadastro de Serviço Prestado</p>
                                        <p>Campo Obrigatório(*)</p>
                                        <h5 style="color:red">
                                            <?php
                                            echo $note;
                                            ?>
                                        </h5>
                                        <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post">

                                            <div class="form-group">
                                                <label>Código do Atendimento*</label>
                                                <input type="text" name="atendimento_id" readonly="true" class="form-control" value="<?php echo $_SESSION['atendimento_id']; ?>" required placeholder="">
                                            </div>

                                            <div class="form-group">
                                                <label>Código do Serviço*</label>
                                                <input type="text" name="servico_id" class="form-control" required placeholder="">
                                            </div>

                                            <div id="btn">
                                                <input type="submit" class="btn btn-primary" value="Cadastrar">
                                                <?php
                                                echo "<a href='atendimento_servicos.php?atendimento_id=" . $_SESSION['atendimento_id'] . "' class='btn btn-cancel'>Voltar</a>&nbsp;&nbsp;&nbsp;";
                                                ?>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br>
                </div>
                <br>
            </div>
            <br>
        </div>

        <!-- Footer Configuration, follow the link to modify-->
        <?php require_once "../components/footer.php" ?>