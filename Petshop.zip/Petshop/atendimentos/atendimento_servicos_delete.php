<?php
require_once "../config.php";
require_once "../login.php";
if (isset($_GET['id'])) {
    try {
        $sql = "SELECT sa.id, sa.atendimento_id, sa.servico_id, s.descricao, s.preco, sa.reg_date
        FROM servico_atendimento sa
        INNER JOIN servico s ON s.servico_id
        WHERE sa.id = '$_GET[id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $atendimento_id = "$linha[atendimento_id]";
        $id = "$linha[id]";
        $servico_id = "$linha[servico_id]";
        $descricao = "$linha[descricao]";
        $preco = "$linha[preco]";
        $reg_date = "$linha[reg_date]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }


    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $sql = "DELETE 
            FROM servico_atendimento
            WHERE id = '$_GET[id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        if ($stmt->error) {
            echo "Error!" . $stmt->error;
            exit();
        } else {
            header("location: atendimento_servicos.php?atendimento_id=" . $linha['atendimento_id'] . "");
            exit();
        }
        $conn = null;
    }
}
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>


                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-7 col-md-7 col-sm-7">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <a href="/petshop/atendimentos/atendimentos.php">| Atendimentos</a>
                                <a>> Serviços Prestados</a>
                                <a>> Remover Serviço Prestado</a>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>

            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Visualizar Atendimento</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="tabel">
                                    <div class="card" style="margin-top:20px;">
                                        <div class="card-body">
                                            <div class="page-header">
                                                <h1>Informações do Atendimento</h1>
                                            </div>
                                            <form action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post">
                                                <div class="form-group">
                                                    <h4>Cógido do Atendimento</h4>
                                                    <p class="form-control-static"><?php echo $atendimento_id; ?></p>
                                                </div>

                                                <div class="form-group">
                                                    <h4>Cógido do Servico</h4>
                                                    <p class="form-control-static"><?php echo $servico_id; ?></p>
                                                </div>

                                                <div class="form-group">
                                                    <h4>Descrição</h4>
                                                    <p class="form-control-static"><?php echo $descricao; ?></p>
                                                </div>

                                                <div class="form-group">
                                                    <h4>Preço</h4>
                                                    <p class="form-control-static"><?php echo $preco; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Data</h4>
                                                    <p class="form-control-static"><?php echo $reg_date; ?></p>
                                                </div>
                                                <div id="btn" class="col-lg-12 col-md-12 col-sm-12">
                                                    <input type="submit" class="btn btn-primary" value="Remover">
                                                    <?php
                                                    echo "<a href='atendimento_servicos.php?atendimento_id=" . $atendimento_id . "' class='btn btn-cancel'>Voltar</a>&nbsp;&nbsp;&nbsp;";
                                                    ?>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                    <br>
                </div>
                <br>
            </div>

<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>