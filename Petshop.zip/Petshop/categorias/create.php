<?php
require_once "../config.php";
require_once "../login.php";
$note = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $sql = "SELECT fornecedor_id
        FROM fornecedor
        WHERE fornecedor_id = '$_POST[fornecedor_id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();

        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $fornecedor_id = "$linha[fornecedor_id]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
    if ($fornecedor_id <> $_POST["fornecedor_id"]) {
        $note = "*Código de Fornecedor não encontrado*";
    } else {
        $sql = "INSERT INTO categoria  (descricao,fornecedor_id,peso,valor_unitario)
        VALUES('$_POST[descricao]','$_POST[fornecedor_id]','$_POST[peso]',CAST(REPLACE(REPLACE('$_POST[valor_unitario]', '.', ''),',','.') AS DECIMAL(6,2)))";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        if ($stmt->error) {
            echo "Error!" . $stmt->error;
            exit();
        } else {
            header("location: categorias.php?");
            exit();
        }
    }
}
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-5 col-md-5 col-sm-5">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <a href="/petshop/principal.php">| Início</a>
                                <a href="categorias.php">> Categorias</a>
                                <a>>Adicionar Categoria</a>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>

            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Cadastrar Categorias</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="tabel">
                                    <div class="card" style="margin-top:20px;">
                                        <div class="card-body">
                                            <div class="page-header">
                                                <h2>Adicionar Categoria</h2>
                                            </div>
                                            <p>Cadastro de Categoria</p>
                                            <p>Campo Obrigatório(*)</p>
                                            <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post">
                                                <h5 style="color:red">
                                                    <?php
                                                    echo $note;
                                                    ?>
                                                </h5>
                                                <div class="form-group">
                                                    <label>Código de Identificação do Fornecedor*</label>
                                                    <input type="text" name="fornecedor_id" class="form-control" required placeholder="">
                                                </div>

                                                <div class="form-group">
                                                    <label>Descrição do Produto*</label>
                                                    <input type="text" name="descricao" class="form-control" required placeholder="">
                                                </div>

                                                <div class="form-group">
                                                    <label>Peso*</label>
                                                    <input type="text" name="peso" class="form-control" required placeholder="">
                                                </div>

                                                <div class="form-group">
                                                    <label>Valor Unitario*</label>
                                                    <input type="text" name="valor_unitario" class="form-control" required placeholder="">
                                                </div>

                                                <div id="btn">
                                                    <input type="submit" class="btn btn-primary" value="Cadastrar">
                                                    <a href="categorias.php" class="btn btn-cancel">Voltar</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                    <br>
                </div>
                <br>
            </div>

<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>