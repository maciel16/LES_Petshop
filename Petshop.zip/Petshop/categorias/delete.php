<?php
require_once "../config.php";
require_once "../login.php";
if (isset($_GET['categoria_id'])) {

    try {
        $sql = $sql = "SELECT f.razao_social,c.categoria_id, c.descricao,c.peso,c.valor_unitario,c.reg_date, c.last_update 
        FROM categoria c
        INNER JOIN fornecedor f ON f.fornecedor_id = c.fornecedor_id
        WHERE c.categoria_id ='$_GET[categoria_id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $razao_social = "$linha[razao_social]";
        $categoria_id = "$linha[categoria_id]";
        $descricao = "$linha[descricao]";
        $peso = "$linha[peso]";
        $valor_unitario = "$linha[valor_unitario]";
        $reg_date = "$linha[reg_date]";
        $last_update = "$linha[last_update]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "DELETE 
            FROM categoria
            WHERE categoria_id = '$_GET[categoria_id]'";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    if ($stmt->error) {
        echo "Error!" . $stmt->error;
        exit();
    } else {
        header("location: categorias.php");
        exit();
    }
    $conn = null;
}

?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-5 col-md-5 col-sm-5">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <a href="/petshop/principal.php">| Início</a>
                                <a href="categorias.php">> Categorias</a>
                                <a>> Remover Categoria</a>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>

            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Remover Categoria </h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="tabel">
                                    <div class="card" style="margin-top:20px;">
                                        <div class="card-body">
                                            <div class="page-header">
                                                <h2>Remover</h2>
                                            </div>
                                            <h1>Deseja realmente remover os dados abaixo?</h1>
                                            <form action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post">
                                                <div class="form-group">
                                                    <h4>Código de Identificação</h4>
                                                    <p class="form-control-static"><?php echo $categoria_id; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Descricao</h4>
                                                    <p class="form-control-static"><?php echo $descricao; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Fornecedor</h4>
                                                    <p class="form-control-static"><?php echo $razao_social; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Peso</h4>
                                                    <p class="form-control-static"><?php echo $peso; ?>Kg</p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Valor Unitario</h4>
                                                    <p class="form-control-static">R$ <?php echo $valor_unitario; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Data de Registro</h4>
                                                    <p class="form-control-static"><?php echo $reg_date; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Ultima Atualização</h4>
                                                    <p class="form-control-static"><?php echo $last_update; ?></p>
                                                </div>
                                                <div id="btn" class="col-lg-12 col-md-12 col-sm-12">
                                                    <input type="submit" class="btn btn-cancel" value="Remover">
                                                    <a href="categorias.php" class="btn btn-primary">Voltar</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                    <br>
                </div>
                <br>
            </div>


<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>