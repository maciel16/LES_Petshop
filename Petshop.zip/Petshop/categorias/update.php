<?php
require_once "../config.php";
require_once "../login.php";
if (isset($_GET['categoria_id'])) {

    try {
        $sql = $sql = "SELECT f.razao_social,c.categoria_id, c.descricao,c.peso,c.valor_unitario,c.reg_date, c.last_update 
        FROM categoria c
        INNER JOIN fornecedor f ON f.fornecedor_id = c.fornecedor_id
        WHERE c.categoria_id ='$_GET[categoria_id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $razao_social = "$linha[razao_social]";
        $categoria_id = "$linha[categoria_id]";
        $descricao = "$linha[descricao]";
        $peso = "$linha[peso]";
        $valor_unitario = "$linha[valor_unitario]";
        $reg_date = "$linha[reg_date]";
        $last_update = "$linha[last_update]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "UPDATE categoria SET descricao = '$_POST[descricao]', peso = '$_POST[peso]', valor_unitario = (CAST(REPLACE(REPLACE('$_POST[valor_unitario]', '.', ''),',','.') AS DECIMAL(6,2))) WHERE categoria_id = '$_GET[categoria_id]'";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    if ($stmt->error) {
        echo "Error!" . $stmt->error;
        exit();
    } else {
        header("location: update.php?categoria_id=$categoria_id");
        exit();
    }

    $conn = null;
}
$conn = null;
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-5 col-md-5 col-sm-5">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <a href="/petshop/principal.php">| Incio</a>
                                <a href="categorias.php">> Categorias</a>
                                <a>> Atualizar Categoria</a>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>

            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Editar Categoria</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="tabel">
                                    <div class="card" style="margin-top:20px;">
                                        <div class="card-body">
                                            <div class="page-header">
                                                <h2>Editar</h2>
                                            </div>
                                            <p>Preencha os novos dados e clique em atualizar para finalizar a edição.</p>
                                            <form action="<?php echo $_SERVER["REQUEST_URI"] ?>" method="post">
                                                <p>Obrigatório(*)</p>
                                                <div class="form-group">
                                                    <label>Numero de Identificação da Categoria*</label>
                                                    <input type="text" name="categoria_id" class="form-control" readonly="true" required placeholder="" value="<?php echo $categoria_id; ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label>Descrição*</label>
                                                    <input type="text" name="descricao" class="form-control" required placeholder="" value="<?php echo $descricao; ?>">
                                                </div>

                                                <div class="form-group">
                                                    <label>Fornecedor*</label>
                                                    <input type="text" name="razao_social" class="form-control" readonly="true" required placeholder="" value="<?php echo $razao_social; ?>">
                                                </div>

                                                <div class="form-group">
                                                    <label>Peso em Quilogramas(Kg)*</label>
                                                    <input type="text" name="peso" class="form-control" required placeholder="" value="<?php echo $peso; ?>">
                                                </div>

                                                <div class="form-group">
                                                    <label>Valor Unitario*</label>
                                                    <input type="text" name="valor_unitario" class="form-control" required placeholder="" value="<?php echo $valor_unitario; ?>">
                                                </div>

                                                <div class="form-group">
                                                    <label>Data de Registro*</label>
                                                    <input type="text" name="reg_date" class="form-control" readonly="true" required value="<?php echo $reg_date; ?>">
                                                </div>

                                                <div class="form-group">
                                                    <label>Ultima Atualização*</label>
                                                    <input type="text" name="last_update" class="form-control" readonly="true" required value="<?php echo $last_update; ?>">
                                                </div>
                                                <div id="btn">
                                                    <input type="submit" class="btn btn-primary" value="Atualizar">
                                                    <a href="categorias.php" class="btn btn-cancel">Voltar</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                    <br>
                </div>
                <br>

 <!-- Sidebar Configuration, follow the link to modify-->
 <?php require_once "../components/footer.php" ?>