<?php
require_once "../config.php";
require_once "../login.php";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "INSERT INTO cliente  (primeiro_nome,ultimo_nome,email,cpf,logradouro,complemento,cep,bairro,cidade,estado,telefone,celular,bdate)
    VALUES('$_POST[primeiro_nome]','$_POST[ultimo_nome]','$_POST[email]','$_POST[cpf]','$_POST[logradouro]','$_POST[complemento]','$_POST[cep]','$_POST[bairro]',
    '$_POST[cidade]','$_POST[estado]','$_POST[telefone]','$_POST[celular]',CONVERT('$_POST[bdate]', DATE))";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    if ($stmt->error) {
        echo "Error!" . $stmt->error;
        exit();
    } else {
        header("location: clientes.php");
        exit();
    }
}
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-5 col-md-5 col-sm-5">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                  <a href="/petshop/principal.php" >| Início</a>
                                <a href="clientes.php" >> Clientes</a>
                                <a >> Adicionar Cliente</a>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>

            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Cadastrar Clientes</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="tabel">
                                    <div class="card" style="margin-top:20px;">
                                        <div class="card-body">
                                            <div class="page-header">
                                                <h2>Adicionar Clientes</h2>
                                            </div>
                                            <p>Cadastro de Clientes</p>
                                            <p>Campo Obrigatório(*)</p>
                                            <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post">
                                                <div class="form-group">
                                                    <label>Nome*</label>
                                                    <input type="text" name="primeiro_nome" class="form-control" required placeholder="">
                                                </div>

                                                <div class="form-group">
                                                    <label>Sobrenome*</label>
                                                    <input type="text" name="ultimo_nome" class="form-control" required placeholder="">
                                                </div>

                                                <fieldset class="form-group">
                                                    <label>Email:*</label>
                                                    <br>
                                                    <input type="email" name="email" value="" class="form-control" required placeholder="seuemail@gmail.com" />
                                                    <span id="email-invalid" style="visibility:hidden">
                                                        Por favor, informe um E-mail valido.</span>
                                                </fieldset>

                                                <fieldset class="form-group">
                                                    <label>CPF:*</label>
                                                    <br>
                                                    <input type="text" name="cpf" class="form-control" required onkeypress="$(this).mask('000.000.000-00')" placeholder="000.000.000-00">
                                                </fieldset>

                                                <div class="form-group">
                                                    <label>Logradouro*</label>
                                                    <input type="text" name="logradouro" class="form-control" required placeholder="Rua:XXXXXXXXXXXXXXXXXX , N°XXXX">
                                                </div>

                                                <div class="form-group">
                                                    <label>Complemento</label>
                                                    <input type="text" name="complemento" class="form-control" placeholder="Bloco:XXXXXXXXXX , Apto°XXXX">
                                                </div>

                                                <fieldset class="form-group">
                                                    <label>CEP:*</label>
                                                    <br>
                                                    <input type="text" name="cep" class="form-control" required onkeypress="$(this).mask('00000-000')" placeholder="XXXXX-XXX">
                                                </fieldset>

                                                <div class="form-group">
                                                    <label>Bairro*</label>
                                                    <input type="text" name="bairro" class="form-control" required placeholder="">
                                                </div>

                                                <fieldset class="form-group">
                                                    <label for="message">Cidade</label>
                                                    <br>
                                                    <select id="cidade" name="cidade" required class="form-control" required>
                                                        <option value="Americana">Americana</option>
                                                        <option value="Nova Odessa">Nova Odessa</option>
                                                        <option value="Santa Barbara d'Oeste">Santa Barbara d'Oeste</option>
                                                        <option value="Sumaré">Sumaré</option>
                                                    </select>
                                                </fieldset>

                                                <div class="form-group">
                                                    <label>Estado*</label>
                                                    <input type="text" name="estado" class="form-control" readonly="true" required value="São Paulo - SP" placeholder="São Paulo - SP">
                                                </div>

                                                <fieldset class="form-group">
                                                    <label>Telefone:</label>
                                                    <br>
                                                    <input type="text" name="telefone" class="form-control" onkeypress="$(this).mask('(00)0000-0000')" placeholder="(XX)XXXX-XXXX">
                                                </fieldset>

                                                <fieldset class="form-group">
                                                    <label>Celular:*</label>
                                                    <br>
                                                    <input type="text" name="celular" class="form-control" required onkeypress="$(this).mask('(00)00000-0000')" placeholder="(XX)XXXXX-XXXX">
                                                </fieldset>

                                                <fieldset class="form-group">
                                                    <label>Data de Nascimento:*</label>
                                                    <br>
                                                    <input type="date" name="bdate" class="form-control" required>
                                                </fieldset>

                                                <div id="btn">
                                                    <input type="submit" class="btn btn-primary" value="Cadastrar">
                                                    <a href="clientes.php" class="btn btn-cancel">Voltar</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                    <br>
                </div>
                <br>
            </div>

<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>