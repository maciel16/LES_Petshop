<?php
require_once "../config.php";
require_once "../login.php";
if (isset($_GET['cliente_id'])) {

    try {
        $sql = "SELECT c.cliente_id, c.primeiro_nome, c.ultimo_nome, c.email, c.cpf, c.logradouro, c.complemento, c.cep,
        c.bairro, c.cidade, c.estado, c.telefone, c.celular, c.bdate, c.reg_date, c.last_update
            FROM cliente c
            WHERE c.cliente_id = '$_GET[cliente_id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();

        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $cliente_id = "$linha[cliente_id]";
        $primeiro_nome ="$linha[primeiro_nome]";
        $ultimo_nome = "$linha[ultimo_nome]";
        $email = "$linha[email]";
        $cpf = "$linha[cpf]";
        $logradouro = "$linha[logradouro]";
        $complemento = "$linha[complemento]";
        $cep = "$linha[cep]";
        $bairro = "$linha[bairro]";
        $cidade = "$linha[cidade]";
        $estado = "$linha[estado]";
        $telefone = "$linha[telefone]";
        $celular = "$linha[celular]";
        $bdate = "$linha[bdate]";
        $reg_date = "$linha[reg_date]";
        $last_update = "$linha[last_update]";

    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
    
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "DELETE 
            FROM cliente
            WHERE cliente_id = '$_GET[cliente_id]'";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    if ($stmt->error) {
        echo "Error!" . $stmt->error;
        exit();
    } else {
        header("location: clientes.php");
        exit();
    }
}

?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-5 col-md-5 col-sm-5">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                  <a href="/petshop/principal.php" >| Início</a>
                                <a href="clientes.php" >> Clientes</a>
                                <a >> Remover Cliente</a>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>

            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Remover Cliente</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="tabel">
                                    <div class="card" style="margin-top:20px;">
                                        <div class="card-body">
                                            <div class="page-header">
                                                <h2>Remover</h2>
                                            </div>
                                            <h1>Deseja realmente remover os dados abaixo?</h1>
                                            <form action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post">
                                                <div class="form-group">
                                                    <h4>Código  de Identificação</h4>
                                                    <p class="form-control-static"><?php echo $cliente_id; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Nome</h4>
                                                    <p class="form-control-static"><?php echo $primeiro_nome; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Sobrenome</h4>
                                                    <p class="form-control-static"><?php echo $ultimo_nome; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Email</h4>
                                                    <p class="form-control-static"><?php echo $email; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>CPF</h4>
                                                    <p class="form-control-static"><?php echo $cpf; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Logradouro</h4>
                                                    <p class="form-control-static"><?php echo $logradouro; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Complemento</h4>
                                                    <p class="form-control-static"><?php echo $complemento; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>CEP</h4>
                                                    <p class="form-control-static"><?php echo $cep; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Bairro</h4>
                                                    <p class="form-control-static"><?php echo $bairro; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Cidade</h4>
                                                    <p class="form-control-static"><?php echo $cidade; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Estado</h4>
                                                    <p class="form-control-static"><?php echo $estado; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Telefone</h4>
                                                    <p class="form-control-static"><?php echo $telefone; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Celular</h4>
                                                    <p class="form-control-static"><?php echo $celular; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Data de Nascimento</h4>
                                                    <p class="form-control-static"><?php echo $bdate; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Data de Registro</h4>
                                                    <p class="form-control-static"><?php echo $reg_date; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Ultima Atualização</h4>
                                                    <p class="form-control-static"><?php echo $last_update; ?></p>
                                                </div>
                                                <div id="btn" class="col-lg-12 col-md-12 col-sm-12">
                                                    <input type="submit" class="btn btn-primary" value="Remover">
                                                    <a href="clientes.php" class="btn btn-cancel">Voltar</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                    <br>
                </div>
                <br>
            </div>

<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>