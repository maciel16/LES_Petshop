<?php
require_once "../config.php";
require_once "../login.php";
if (isset($_GET['cliente_id'])) {

    try {
        $sql = "SELECT c.cliente_id, c.primeiro_nome, c.ultimo_nome, c.email, c.cpf, c.logradouro, c.complemento, c.cep,
        c.bairro, c.cidade, c.estado, c.telefone, c.celular, c.bdate, c.reg_date, c.last_update
            FROM cliente c
            WHERE c.cliente_id = '$_GET[cliente_id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();

        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $cliente_id = "$linha[cliente_id]";
        $primeiro_nome = "$linha[primeiro_nome]";
        $ultimo_nome = "$linha[ultimo_nome]";
        $email = "$linha[email]";
        $cpf = "$linha[cpf]";
        $logradouro = "$linha[logradouro]";
        $complemento = "$linha[complemento]";
        $cep = "$linha[cep]";
        $bairro = "$linha[bairro]";
        $cidade = "$linha[cidade]";
        $estado = "$linha[estado]";
        $telefone = "$linha[telefone]";
        $celular = "$linha[celular]";
        $bdate = "$linha[bdate]";
        $reg_date = "$linha[reg_date]";
        $last_update = "$linha[last_update]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "UPDATE cliente SET primeiro_nome = '$_POST[primeiro_nome]', ultimo_nome = '$_POST[ultimo_nome]', email = '$_POST[email]', logradouro = '$_POST[logradouro]',
    complemento = '$_POST[complemento]', cep = '$_POST[cep]', bairro = '$_POST[bairro]', cidade = '$_POST[cidade]', telefone = '$_POST[telefone]',
    celular = '$_POST[celular]' WHERE cliente_id = '$_POST[cliente_id]'";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    if ($stmt->error) {
        echo "Error!" . $stmt->error;
        exit();
    } else {
        header("location: update.php?cliente_id=$cliente_id");
        exit();
    }
}
$conn = null;
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

        <div class="">
            <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                    <div class="navbar-header">
                        <button type="button" id="sidebarCollapse" class="navbar-btn">
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>

                    <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-6 col-md-6 col-sm-6">
                        <div id="" class="col-lg-12 col-md-12 col-sm-12">
                            <a href="/petshop/principal.php">| Incio</a>
                            <a href="clientes.php">> Clientes</a>
                            <a>> Alterar Cadastro de Cliente</a>
                        </div>
                    </div>
                </div>
            </nav>

        </div>

        <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
            <h2>Alterar Usuários</h2>

        </div>

        <div class="block col-lg-12 col-md-12 col-sm-12">
            <br>
            <div class="table">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div id="tabel">
                                <div class="card" style="margin-top:20px;">
                                    <div class="card-body">
                                        <div class="page-header">
                                            <h2>Alterar</h2>
                                        </div>
                                        <p>Preencha os novos dados e clique em atualizar para finalizar a edição.</p>
                                        <form action="<?php echo $_SERVER["REQUEST_URI"] ?>" method="post">
                                            <p>Campo Obrigatório(*)</p>
                                            <div class="form-group">
                                                <label>Código de Identificação*</label>
                                                <input type="text" name="cliente_id" class="form-control" readonly="true" required placeholder="" value="<?php echo $cliente_id; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label>Nome*</label>
                                                <input type="text" name="primeiro_nome" class="form-control" required placeholder="" value="<?php echo $primeiro_nome; ?>">
                                            </div>

                                            <div class="form-group">
                                                <label>Sobrenome*</label>
                                                <input type="text" name="ultimo_nome" class="form-control" required placeholder="" value="<?php echo $ultimo_nome; ?>">
                                            </div>

                                            <fieldset class="form-group">
                                                <label>Email:*</label>
                                                <br>
                                                <input type="email" name="email" class="form-control" required value="<?php echo $email; ?>" />
                                                <span id="email-invalid" style="visibility:hidden">
                                                    Por favor, informe um E-mail valido.</span>
                                            </fieldset>

                                            <fieldset class="form-group">
                                                <label>CPF:*</label>
                                                <br>
                                                <input type="text" name="cpf" class="form-control" readonly="true" required onkeypress="$(this).mask('000.000.000-00')" placeholder="000.000.000-00" value="<?php echo $cpf; ?>">
                                            </fieldset>

                                            <div class="form-group">
                                                <label>Logradouro*</label>
                                                <input type="text" name="logradouro" class="form-control" required placeholder="Rua:XXXXXXXXXXXXXXXXXX , N°XXXX" value="<?php echo $logradouro; ?>">
                                            </div>

                                            <div class="form-group">
                                                <label>Complemento</label>
                                                <input type="text" name="complemento" class="form-control" placeholder="Bloco:XXXXXXXXXX , Apto°XXXX" value="<?php echo $complemento; ?>">
                                            </div>

                                            <fieldset class="form-group">
                                                <label>CEP:*</label>
                                                <br>
                                                <input type="text" name="cep" class="form-control" required onkeypress="$(this).mask('00000-000')" placeholder="XXXXX-XXX" value="<?php echo $cep; ?>">
                                            </fieldset>

                                            <div class="form-group">
                                                <label>Bairro*</label>
                                                <input type="text" name="bairro" class="form-control" required value="<?php echo $bairro; ?>">
                                            </div>

                                            <fieldset class="form-group">
                                                <label for="message">Cidade</label>
                                                <br>
                                                <select id="cidade" name="cidade" required class="form-control" required>
                                                    <option selected="<?php $cidade; ?>"><?php echo $cidade; ?></option>
                                                    <option value="Americana">Americana</option>
                                                    <option value="Nova Odessa">Nova Odessa</option>
                                                    <option value="Santa Barbara d'Oeste">Santa Barbara d'Oeste</option>
                                                    <option value="Sumaré">Sumaré</option>
                                                </select>
                                            </fieldset>

                                            <div class="form-group">
                                                <label>Estado*</label>
                                                <input type="text" name="estado" class="form-control" readonly="true" required value="<?php echo $estado; ?>">
                                            </div>

                                            <fieldset class="form-group">
                                                <label>Telefone:</label>
                                                <br>
                                                <input type="text" name="telefone" class="form-control" onkeypress="$(this).mask('(00)0000-0000')" placeholder="(XX)XXXX-XXXX" value="<?php echo $telefone; ?>">
                                            </fieldset>

                                            <fieldset class="form-group">
                                                <label>Celular:*</label>
                                                <br>
                                                <input type="text" name="celular" class="form-control" required onkeypress="$(this).mask('(00)00000-0000')" placeholder="(XX)XXXXX-XXXX" value="<?php echo $celular; ?>">
                                            </fieldset>

                                            <fieldset class="form-group">
                                                <label>Data de Nascimento:*</label>
                                                <br>
                                                <input type="date" name="login" class="form-control" readonly="true" required value="<?php echo $bdate; ?>">
                                            </fieldset>

                                            <div class="form-group">
                                                <label>Data de Registro*</label>
                                                <input type="text" name="reg_date" class="form-control" readonly="true" required value="<?php echo $reg_date; ?>">
                                            </div>

                                            <div class="form-group">
                                                <label>Ultima Atualização*</label>
                                                <input type="text" name="last_update" class="form-control" readonly="true" required value="<?php echo $last_update; ?>">
                                            </div>
                                            <div id="btn">
                                                <input type="submit" class="btn btn-primary" value="Atualizar">
                                                <a href="clientes.php" class="btn btn-cancel">Voltar</a>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br>
                </div>
                <br>
            </div>
            <br>
        </div>

        <!-- Footer Configuration, follow the link to modify-->
        <?php require_once "../components/footer.php" ?>