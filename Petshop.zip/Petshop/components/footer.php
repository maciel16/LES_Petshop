<div class="Contato col-lg-12 col-md-12 col-sm-12">


    <div class="TelefoneEmail col-lg-4 col-md-4 col-sm-4">
        <h1>GPet<a><img src="/petshop/images/cat.png" width=60px;></h1>
        <h4>Sistema de Gestão de Petshops e Clínicas Veterinárias</h4>
            <strong>Versão: </strong> 1.0.0<br>
            <strong>Ref:</strong> Jul/2020<br>
        </a>
        <br>
        

    </div>


    <div class="Endereco col-lg-4 col-md-4 col-sm-4">
        <h4>Faculdade de Tecnologia de Americana - Ministro Ralph Biasi</h4>
        <a href="https://www.google.com/maps/place/Fatec+Americana+-+Faculdade+de+Tecnologia+de+Americana/@-22.7397892,-47.3503339,15z/data=!4m5!3m4!1s0x0:0xffb368bd91ea12ae!8m2!3d-22.7397892!4d-47.3503339">
            <strong>Rua: </strong> Emílio de Menezes<br>
            <strong>Bairro:</strong> Vila Amorim<br>
            <strong>Cidade:</strong> Americana - SP<br>
            <strong>CEP:</strong> 13469-111<br>
        </a>
        <br>

    </div>


    <div class="Mapa col-lg-4 col-md-4 col-sm-4">
        <h4>Google Maps</h4>
        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14718.756951804433!2d-47.3503339!3d-22.7397892!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xffb368bd91ea12ae!2sFatec%20Americana%20-%20Faculdade%20de%20Tecnologia%20de%20Americana!5e0!3m2!1spt-BR!2sbr!4v1593179920051!5m2!1spt-BR!2sbr" width="90%" height="50%" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
        <br>

    </div>



</div>

<div class="footer col-lg-12 col-md-12 col-sm-12">
    <br>
    <p> &copy; GPet <?php echo date("Y"); ?>/ Desinged by JMR </p>
</div>

</div>
<!-- jQuery CDN -->
<script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
<!-- Bootstrap Js CDN -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<!-- Botton Top -->
<script type="text/javascript" src="/petshop/js/bttop.js"></script>
<!-- Side Bar -->
<script type="text/javascript" src="/petshop/js/sidebar.js"></script>
<!-- Side Bar -->
<script type="text/javascript" src="/petshop/js/slideshow.js"></script>

<script type="text/javascript" src="/petshop/js/demo.js"></script>


<!-- Magnific Popup -->
<script src="/petshop/js/jquery.magnific-popup.min.js"></script>

<script src="/petshop/js/magnific-popup-options.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

</body>

</html>