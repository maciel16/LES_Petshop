<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="description=" content="Serviços de Desenvolvimento de Sistemas, Manutenção de Computadores e Design">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">


    <title>GPet</title>
    <link rel="shortcut icon" type="image/x-icon" href="images/logo/favicon.ico">

    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

    <!-- Button Top CSS CDN -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.0.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Merriweather:400,900,900i" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="/petshop/css/style.css" rel="stylesheet">
    <link href="/petshop/css/topbt.css" rel="stylesheet">
    <link href="/petshop/css/slideshow.css" rel="stylesheet">
    <link href="/petshop/css/column.css" rel="stylesheet">
    <link href="/petshop/css/sidebar.css" rel="stylesheet">
    <link href="/petshop/css/pcs.css" rel="stylesheet">
    <link href="/petshop/css/incio.css" rel="stylesheet">
</head>

<body>
    <a id="button"></a>

    <div class="header">
        <h1>GPet<a><img src="/petshop/images/cat.png" width=60px;></h1>
    </div>