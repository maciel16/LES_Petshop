<nav id="sidebar">
    <div class="sidebar-header">
        <a href="index.html">
            <a> <?php echo "Olá, " . $_SESSION["nome"] . ""; ?><img src="/petshop/images/catb.png" width=50; height=50></a>
        </a>
    </div>
    <ul class="list-unstyled components">
        <li>
            <a href="/petshop/principal.php">Início  <img src="/petshop/images/home.png" width=20; height=20></a>
            <a href="#Administrativo" data-toggle="collapse" aria-expanded="false">Administrativo <img src="/petshop/images/admin.png" width=30; height=30></a>
            <ul class="collapse list-unstyled" id="Administrativo">
                <li><a href="/petshop/usuarios/usuarios.php">Gerenciar Funcionários</a></li>
                <li><a href="/petshop/ponto/ponto.php">Gerenciar Horas Trabalhadas</a></li>
            </ul>
            <a href="#Atendimentos" data-toggle="collapse" aria-expanded="false">Atendimentos <img src="/petshop/images/form.png" width=30; height=30></a>
            <ul class="collapse list-unstyled" id="Atendimentos">
                <li><a href="/petshop/atendimentos/atendimentos.php">Gerenciar Atendimentos</a></li>
                <li><a href="/petshop/hist_atendimentos/hist_atendimentos.php">Histórico de Atendimentos</a></li>
            </ul>
            <a href="#Clientes" data-toggle="collapse" aria-expanded="false">Clientes<img src="/petshop/images/cat.png" width=30; height=30></a>
            <ul class="collapse list-unstyled" id="Clientes">
                <li><a href="/petshop/clientes/clientes.php">Gerenciar Clientes</a></li>
                <li><a href="/petshop/animais/animais.php">Gerenciar Animais</a></li>
            </ul>
            <a href="#Compras" data-toggle="collapse" aria-expanded="false">Compras<img src="/petshop/images/buy.png" width=30; height=30></a>
            <ul class="collapse list-unstyled" id="Compras">
                <li><a href="/petshop/compras/compras.php">Gerenciar Compras</a></li>
                <li><a href="/petshop/hist_compras/hist_compras.php">Histórico de Compras</a></li>
            </ul>
            <a href="#Financeiro" data-toggle="collapse" aria-expanded="false">Financeiro<img src="/petshop/images/finance.png" width=30; height=30></a>
            <ul class="collapse list-unstyled" id="Financeiro">
                <li><a href="/petshop/hist_transacoes/hist_transacoes.php">Histórico de Transações</a></li>
            </ul>
            <a href="#Fornecedores" data-toggle="collapse" aria-expanded="false">Fornecedores<img src="/petshop/images/delivery.png" width=30; height=30></a>
            <ul class="collapse list-unstyled" id="Fornecedores">
                <li><a href="/petshop/fornecedores/fornecedores.php">Gerenciar Fornecedores</a></li>
                <li><a href="/petshop/representantes/representantes.php">Gerenciar Representantes</a></li>
            </ul>
            <a href="#Produtos" data-toggle="collapse" aria-expanded="false">Produtos<img src="/petshop/images/box.png" width=30; height=30></a>
            <ul class="collapse list-unstyled" id="Produtos">
                <li><a href="/petshop/categorias/categorias.php">Gerenciar Categorias de Produtos</a></li>
                <li><a href="/petshop/produtos/produtos.php">Gerenciar Produtos</a></li>
                <li><a href="/petshop/inventario/inventario.php">Inventário</a></li>
            </ul>
            <a href="#Servicos" data-toggle="collapse" aria-expanded="false">Serviços<img src="/petshop/images/services.png" width=30; height=30></a>
            <ul class="collapse list-unstyled" id="Servicos">
                <li><a href="/petshop/servicos/servicos.php">Gerenciar Serviços</a></li>
            </ul>
            <a href="#Vendas" data-toggle="collapse" aria-expanded="false">Vendas<img src="/petshop/images/price.png" width=30; height=30></a>
            <ul class="collapse list-unstyled" id="Vendas">
                <li><a href="/petshop/vendas/vendas.php">Gerenciar Vendas</a></li>
                <li><a href="/petshop/hist_vendas/hist_vendas.php">Histórico de Vendas</a></li>
            </ul>
        </li>
    </ul>
    <ul class="list-unstyled CTAs">
        <li><a href="?sair" class="article">Encerrar Sessão</a></li>
    </ul>
</nav>