<?php
require_once "../config.php";
require_once "../login.php";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "INSERT INTO fornecedor  (razao_social,email,cnpj,logradouro,complemento,cep,bairro,cidade,estado,telefone)
    VALUES('$_POST[razao_social]','$_POST[email]','$_POST[cnpj]','$_POST[logradouro]','$_POST[complemento]','$_POST[cep]','$_POST[bairro]',
    '$_POST[cidade]','$_POST[estado]','$_POST[telefone]')";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    if ($stmt->error) {
        echo "Error!" . $stmt->error;
        exit();
    } else {
        header("location: fornecedores.php");
        exit();
    }
}
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

        <div class="">
            <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                    <div class="navbar-header">
                        <button type="button" id="sidebarCollapse" class="navbar-btn">
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>

                    <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-5 col-md-5 col-sm-5">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <a href="/petshop/principal.php">| Início</a>
                                <a href="fornecedores.php">> Fornecedores</a>
                                <a>> Cadastrar Fornecedor</a>
                            </div>
                        </div>
                </div>
            </nav>

        </div>

        <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
            <h2>Cadastrar Fornecedores</h2>

        </div>

        <div class="block col-lg-12 col-md-12 col-sm-12">
            <br>
            <div class="table">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div id="tabel">
                                <div class="card" style="margin-top:20px;">
                                    <div class="card-body">
                                        <div class="page-header">
                                            <h2>Cadastrar Fornecedor</h2>
                                        </div>
                                        <p>Cadastro de Fornecedores</p>
                                        <p>Campo Obrigatório(*)</p>
                                        <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post">
                                            <div class="form-group">
                                                <label>Razão Social*</label>
                                                <input type="text" name="razao_social" class="form-control" required placeholder="">
                                            </div>

                                            <fieldset class="form-group">
                                                <label>Email:*</label>
                                                <br>
                                                <input type="email" name="email" value="" class="form-control" required placeholder="seuemail@gmail.com" />
                                                <span id="email-invalid" style="visibility:hidden">
                                                    Por favor, informe um E-mail valido.</span>
                                            </fieldset>

                                            <fieldset class="form-group">
                                                <label>CNPJ:*</label>
                                                <br>
                                                <input type="text" name="cnpj" class="form-control" required onkeypress="$(this).mask('00.000.000/0000-00')" placeholder="00.000.000/0000-00'">
                                            </fieldset>

                                            <div class="form-group">
                                                <label>Logradouro*</label>
                                                <input type="text" name="logradouro" class="form-control" required placeholder="Rua:XXXXXXXXXXXXXXXXXX , N°XXXX">
                                            </div>

                                            <div class="form-group">
                                                <label>Complemento</label>
                                                <input type="text" name="complemento" class="form-control" placeholder="Bloco:XXXXXXXXXX , Apto°XXXX">
                                            </div>

                                            <fieldset class="form-group">
                                                <label>CEP:*</label>
                                                <br>
                                                <input type="text" name="cep" class="form-control" required onkeypress="$(this).mask('00000-000')" placeholder="XXXXX-XXX">
                                            </fieldset>

                                            <div class="form-group">
                                                <label>Bairro*</label>
                                                <input type="text" name="bairro" class="form-control" required placeholder="">
                                            </div>

                                            <div class="form-group">
                                                <label>Cidade*</label>
                                                <input type="text" name="cidade" class="form-control" required value="" placeholder="Ex:São Paulo - SP">
                                            </div>

                                            <fieldset class="form-group">
                                                <label for="message">Estado</label>
                                                <br>
                                                <select id="estado" name="estado" required class="form-control" required>
                                                    <option value="Acre">Acre</option>
                                                    <option value="Alagoas">Alagoas</option>
                                                    <option value="Amapá">Amapá</option>
                                                    <option value="Amazonas">Amazonas</option>
                                                    <option value="Bahia">Bahia</option>
                                                    <option value="Ceará">Ceará</option>
                                                    <option value="Distrito Federal">Distrito Federal</option>
                                                    <option value="Espírito Santo">Espírito Santo</option>
                                                    <option value="Goiás">Goiás</option>
                                                    <option value="Maranhão">Maranhão</option>
                                                    <option value="Mato Grosso">Mato Grosso</option>
                                                    <option value="Mato Grosso do Sul">Mato Grosso do Sul</option>
                                                    <option value="Minas GeraisG">Minas Gerais</option>
                                                    <option value="Pará">Pará</option>
                                                    <option value="Paraíba">Paraíba</option>
                                                    <option value="Paraná">Paraná</option>
                                                    <option value="Pernambuco">Pernambuco</option>
                                                    <option value="Piauí">Piauí</option>
                                                    <option value="Rio de Janeiro">Rio de Janeiro</option>
                                                    <option value="Rio Grande do Norte">Rio Grande do Norte</option>
                                                    <option value="Rio Grande do Sul">Rio Grande do Sul</option>
                                                    <option value="Rondônia">Rondônia</option>
                                                    <option value="Roraima">Roraima</option>
                                                    <option value="Santa Catarina">Santa Catarina</option>
                                                    <option value="São Paulo">São Paulo</option>
                                                    <option value="Sergipe">Sergipe</option>
                                                    <option value="Tocantins">Tocantins</option>
                                                </select>
                                            </fieldset>

                                            <fieldset class="form-group">
                                                <label>Telefone:</label>
                                                <br>
                                                <input type="text" name="telefone" class="form-control" onkeypress="$(this).mask('(00)0000-0000')" placeholder="(XX)XXXX-XXXX">
                                            </fieldset>

                                            <div id="btn">
                                                <input type="submit" class="btn btn-primary" value="Cadastrar">
                                                <a href="fornecedores.php" class="btn btn-cancel">Voltar</a>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br>
                </div>
                <br>
            </div>
            <br>
        </div>


<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>