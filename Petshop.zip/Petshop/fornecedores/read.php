<?php
require_once "../login.php";
require_once "../config.php";
if (isset($_GET['fornecedor_id'])) {

    try {
        $sql = "SELECT f.fornecedor_id, f.razao_social, f.email, f.cnpj, f.logradouro, f.complemento, f.cep,
        f.bairro, f.cidade, f.estado, f.telefone, f.reg_date, f.last_update
            FROM fornecedor f
            WHERE f.fornecedor_id = '$_GET[fornecedor_id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $fornecedor_id = "$linha[fornecedor_id]";
        $razao_social ="$linha[razao_social]";
        $email = "$linha[email]";
        $cnpj = "$linha[cnpj]";
        $logradouro = "$linha[logradouro]";
        $complemento = "$linha[complemento]";
        $cep = "$linha[cep]";
        $bairro = "$linha[bairro]";
        $cidade = "$linha[cidade]";
        $estado = "$linha[estado]";
        $telefone = "$linha[telefone]";
        $reg_date = "$linha[reg_date]";
        $last_update = "$linha[last_update]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
    $conn = null;
}
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-6 col-md-6 col-sm-6">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <a href="/petshop/principal.php">| Início</a>
                                <a href="fornecedores.php">> Fornecedores</a>
                                <a>> Visualizar Fornecedor</a>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>

            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Visualizar Fornecedores</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="tabel">
                                    <div class="card" style="margin-top:20px;">
                                        <div class="card-body">
                                            <div class="page-header">
                                                <h1>Informações do Fornecedor</h1>
                                            </div>
                                            <div class="form-group">
                                                <h4>Código  de Identificação</h4>
                                                <p class="form-control-static"><?php echo $fornecedor_id; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Razão Social</h4>
                                                <p class="form-control-static"><?php echo $razao_social; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Email</h4>
                                                <p class="form-control-static"><?php echo $email; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>CNPJ</h4>
                                                <p class="form-control-static"><?php echo $cnpj; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Logradouro</h4>
                                                <p class="form-control-static"><?php echo $logradouro; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Complemento</h4>
                                                <p class="form-control-static"><?php echo $complemento; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>CEP</h4>
                                                <p class="form-control-static"><?php echo $cep; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Bairro</h4>
                                                <p class="form-control-static"><?php echo $bairro; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Cidade</h4>
                                                <p class="form-control-static"><?php echo $cidade; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Estado</h4>
                                                <p class="form-control-static"><?php echo $estado; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Telefone</h4>
                                                <p class="form-control-static"><?php echo $telefone; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Data de Registro</h4>
                                                <p class="form-control-static"><?php echo $reg_date; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Ultima Atualização</h4>
                                                <p class="form-control-static"><?php echo $last_update; ?></p>
                                            </div>
                                            <div id="btn">
                                                <a href="fornecedores.php" class="btn btn-cancel">Voltar</a>
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                    <br>
                </div>
                <br>
            </div>

<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>