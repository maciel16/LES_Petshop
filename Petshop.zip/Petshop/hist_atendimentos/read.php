<?php
require_once "../config.php";
require_once "../login.php";
if (isset($_GET['atendimento_id'])) {

    try {
        $sql = $sql = "SELECT ate.atendimento_id,a.animal_id, a.nome, CONCAT(c.primeiro_nome,' ',c.ultimo_nome) dono, ate.descricao, ate.valor, ate.reg_date, ate.last_update 
        FROM atendimento ate
        INNER JOIN  animal a ON a.animal_id = ate.animal_id
        INNER JOIN  cliente_animal ca ON ca.animal_id = a.animal_id
        INNER JOIN  cliente c ON c.cliente_id = c.cliente_id
        WHERE ate.atendimento_id = '$_GET[atendimento_id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $atendimento_id = "$linha[atendimento_id]";
        $animal_id = "$linha[animal_id]";
        $dono = "$linha[dono]";
        $nome = "$linha[nome]";
        $descricao = "$linha[descricao]";
        $valor = "$linha[valor]";
        $reg_date = "$linha[reg_date]";
        $last_update = "$linha[last_update]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
    $conn = null;
}
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>


                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-9 col-md-9 col-sm-9">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <a href="/petshop/principal.php">| Início</a>
                                <a href="hist_atendimentoss.php">> Histórico de Atendimentos</a>
                                <a>> Visualizar Histórico de Atendimento</a>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>

            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Visualizar Histórico de Atendimento</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="tabel">
                                    <div class="card" style="margin-top:20px;">
                                        <div class="card-body">
                                            <div class="page-header">
                                                <h1>Informações do Atendimento</h1>
                                            </div>
                                            <div class="form-group">
                                                <h4>Cógido do Atendimento</h4>
                                                <p class="form-control-static"><?php echo $atendimento_id; ?></p>
                                            </div>

                                            <div class="form-group">
                                                <h4>Código de Identificação do Animal</h4>
                                                <p class="form-control-static"><?php echo $animal_id; ?></p>
                                            </div>

                                            <div class="form-group">
                                                <h4>Nome</h4>
                                                <p class="form-control-static"><?php echo $nome; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Dono</h4>
                                                <p class="form-control-static"><?php echo $dono; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Descrição do Atendimento</h4>
                                                <p class="form-control-static"><?php echo $descricao; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Valor dos Serviços Prestados</h4>
                                                <p class="form-control-static">R$<?php echo $valor; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Data de Registro</h4>
                                                <p class="form-control-static"><?php echo $reg_date; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Ultima Atualização</h4>
                                                <p class="form-control-static"><?php echo $last_update; ?></p>
                                            </div>
                                            <div id="btn">
                                                <a href="hist_atendimentos.php" class="btn btn-cancel">Voltar</a>
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                    <br>
                </div>
                <br>
            </div>

<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>