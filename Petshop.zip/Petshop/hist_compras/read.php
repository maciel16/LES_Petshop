<?php
require_once "../config.php";
require_once "../login.php";
if (isset($_GET['compra_id'])) {

    try {
        $sql = $sql = "SELECT c.compra_id, c.fornecedor_id, f.razao_social, c.descricao, c.valor, c.reg_date
        FROM compra c
        INNER JOIN fornecedor f ON f.fornecedor_id = c.fornecedor_id
        WHERE c.compra_id = '$_GET[compra_id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $compra_id = "$linha[compra_id]";
        $fornecedor_id = "$linha[fornecedor_id]";
        $razao_social = "$linha[razao_social]";
        $descricao = "$linha[descricao]";
        $valor = "$linha[valor]";
        $reg_date = "$linha[reg_date]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
    $conn = null;
}
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-8 col-md-8 col-sm-8">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <a href="/petshop/principal.php">| Início</a>
                                <a href="hist_compras.php">> Histórico de Compras</a>
                                <a>> Visualizar  Histórico de Compras</a>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>

            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Visualizar  Histórico de Compras</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="tabel">
                                    <div class="card" style="margin-top:20px;">
                                        <div class="card-body">
                                            <div class="page-header">
                                                <h1>Informações da Compra</h1>
                                            </div>
                                            <div class="form-group">
                                                <h4>Cógido da Compra</h4>
                                                <p class="form-control-static"><?php echo $compra_id; ?></p>
                                            </div>

                                            <div class="form-group">
                                                <h4>Código de Identificação do Fornecedor</h4>
                                                <p class="form-control-static"><?php echo $fornecedor_id; ?></p>
                                            </div>
                                            
                                            <div class="form-group">
                                                <h4>Razão Social</h4>
                                                <p class="form-control-static"><?php echo $razao_social; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Descrição da Compra</h4>
                                                <p class="form-control-static"><?php echo $descricao; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Valor dos Total da Compra</h4>
                                                <p class="form-control-static">R$<?php echo $valor; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Data de Registro</h4>
                                                <p class="form-control-static"><?php echo $reg_date; ?></p>
                                            </div>
                                            <div id="btn">
                                                <a href="hist_compras.php" class="btn btn-cancel">Voltar</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                    <br>
                </div>
                <br>
            </div>

<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>