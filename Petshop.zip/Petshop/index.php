<?php
// Start the session
session_start();
if (isset($_SESSION['logado'])) {
    header("location: principal.php");
    die();
}
require_once "config.php";
$note = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "SELECT u.login, u.senha, u.primeiro_nome, u.ultimo_nome, u.funcao
        FROM usuario u
        WHERE u.login = '$_POST[login]'";
    $stmt = $conn->prepare($sql);
    $stmt->execute();

    $linha = $stmt->fetch(PDO::FETCH_ASSOC);
    $login = "$linha[login]";
    $senha = "$linha[senha]";
    $funcao = "$linha[funcao]";

    if (($login <> "$_POST[login]") || ($senha <> "$_POST[senha]")) {
        $note = "*Login ou Senha incorretos*";
    } else {
        $_SESSION["nome"] = $linha['primeiro_nome'];
        $_SESSION['logado'] = true;
        header("location: principal.php?");
        exit();
    }
    /*
    ---------- Verifica se há erro de banco ----------
    if ($stmt->error) {
    echo "Error!" . $stmt->error;
    exit();
    } 
    */
}

$conn = null;
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "./components/head.php" ?>
<div class="wrapper">
    <!-- Sidebar Configuration, follow the link to modify-->

    <div id="content">

        <div class="">
            <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">
                    <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-3 col-md-3 col-sm-3" style="color:white">
                        |Login
                    </div>
                </div>
            </nav>

        </div>

        <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
            <h2>Insira abaixo suas credenciais</h2>

        </div>

        <div class="block col-lg-12 col-md-12 col-sm-12">
            <br>
            <div class="table">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4">
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <div id="tabel">
                                <div class="card" style="margin-top:20px;">
                                    <div class="card-body">
                                        <div class="page-header">
                                        </div>
                                        <form action="<?php echo $_SERVER["REQUEST_URI"] ?>" method="post">
                                            <h5 style="color:red">
                                                <?php
                                                echo $note;
                                                ?>
                                            </h5>
                                            <div class="form-group">
                                                <h4>Login*</h4>
                                                <input type="text" name="login" class="form-control" required placeholder="">
                                            </div>
                                            <div class="form-group">
                                                <h4>Senha*</h4>
                                                <input type="password" name="senha" class="form-control" required placeholder="">
                                            </div>

                                            <div id="btn">
                                                <input type="submit" class="btn btn-primary" value="Login">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4">
                        </div>
                    </div>
                    <br>
                </div>
                <br>
            </div>
        </div>
        <br>
        <!-- Footer Configuration, follow the link to modify-->
        <?php require_once "./components/footer.php" ?>