<?php
require_once "../config.php";
require_once "../login.php";
if (isset($_GET['inventario_id'])) {

    try {
        $sql = $sql = "SELECT i.inventario_id, c.descricao, i.qtd,  i.last_update, i.reg_date
        FROM inventario i
        INNER JOIN categoria c ON i.categoria_id = c.categoria_id
        WHERE i.inventario_id ='$_GET[inventario_id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $inventario_id = "$linha[inventario_id]";
        $descricao = "$linha[descricao]";
        $qtd = "$linha[qtd]";
        $reg_date = "$linha[reg_date]";
        $last_update = "$linha[last_update]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
    $conn = null;
}
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-5 col-md-5 col-sm-5">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <a href="/petshop/principal.php">| Início</a>
                                <a href="inventario.php">> Estoque</a>
                                <a>> Visualizar Estoque</a>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>

            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Visualizar Inventario</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="tabel">
                                    <div class="card" style="margin-top:20px;">
                                        <div class="card-body">
                                            <div class="page-header">
                                                <h1>Inventario</h1>
                                            </div>
                                            <div class="form-group">
                                                <h4>Código do Produto</h4>
                                                <p class="form-control-static"><?php echo $inventario_id; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Descricao</h4>
                                                <p class="form-control-static"><?php echo $descricao; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Quantidade</h4>
                                                <p class="form-control-static"><?php echo $qtd; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Data de Registro</h4>
                                                <p class="form-control-static"><?php echo $reg_date; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Ultima Atualização</h4>
                                                <p class="form-control-static"><?php echo $last_update; ?></p>
                                            </div>
                                            <div id="btn">
                                                <a href="inventario.php" class="btn btn-cancel">Voltar</a>
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                    <br>
                </div>
                <br>
            </div>

<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>