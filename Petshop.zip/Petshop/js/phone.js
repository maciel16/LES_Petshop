$(document).ready(function(){
    $('#telefone').mask('(00) 0000-0000#');
});