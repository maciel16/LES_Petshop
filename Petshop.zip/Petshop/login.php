<?php
// Start the session
session_start();
if (!isset($_SESSION['logado'])) {
    header("location: /petshop/index.php?");
    session_destroy();
}

if (isset($_GET['sair'])) {
    header("location: /petshop/index.php?");
    session_destroy();
}
?>