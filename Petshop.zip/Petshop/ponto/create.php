<?php
require_once "../config.php";
require_once "../login.php";
$note = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $sql = "SELECT hs.user_id, hs.mes, hs.ano
        FROM hora_salario hs
        WHERE hs.user_id = '$_POST[user_id]'
        AND hs.mes = '$_POST[mes]'
        AND hs.ano = '$_POST[ano]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();

        $linha = $stmt->fetch(PDO::FETCH_ASSOC);

        $user_id = "$linha[user_id]";
        $mes = "$linha[mes]";
        $ano = "$linha[ano]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }

    try {
        $sql2 = "SELECT user_id
        FROM usuario
        WHERE user_id = '$_POST[user_id]'";
        $stmt2 = $conn->prepare($sql2);
        $stmt2->execute();

        $linha2 = $stmt2->fetch(PDO::FETCH_ASSOC);

        $usuario = "$linha2[user_id]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }

    if ($usuario !== $_POST["user_id"]) {
        $note = "Funcionário não encontrado";
    } else {
        if ((($user_id == $_POST["user_id"]) & ($mes == $_POST["mes"])) & ($ano == $_POST["ano"])) {
            $note = "*Referência já cadastrada*";
        } else {
            $sql = "INSERT INTO hora_salario(user_id,mes,ano,valor_hora)
            VALUES('$_POST[user_id]','$_POST[mes]','$_POST[ano]',CAST(REPLACE(REPLACE('$_POST[valor_hora]', '.', ''),',','.') AS DECIMAL(6,2)))";
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            if ($stmt->error) {
                echo "Error!" . $stmt->error;
                exit();
            } else {
                header("location: ponto.php");
                exit();
            }
        }
    }
    $conn = null;
}

?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-6 col-md-6 col-sm-6">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <a href="/petshop/principal.php">| Início</a>
                                <a href="ponto.php">> Holerite</a>
                                <a>> Adicionar Novo Holerite</a>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>

            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Adicionar Nova Referência</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="tabel">
                                    <div class="card" style="margin-top:20px;">
                                        <div class="card-body">
                                            <div class="page-header">
                                                <h2>Referência</h2>
                                            </div>
                                            <p>Cadastro de Referência de Horas</p>
                                            <p>Campo Obrigatório(*)</p>
                                            <h5 style="color:red">
                                                <?php
                                                echo $note;
                                                ?>
                                            </h5>
                                            <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post">
                                                <div class="form-group">
                                                    <label>Identificação de Usuário*</label>
                                                    <input type="text" name="user_id" class="form-control" required placeholder="">
                                                </div>

                                                <div class="form-group">
                                                    <label>Valor por Hora de Trabalho em Reais(R$)*</label>
                                                    <input type="text" name="valor_hora" class="form-control" required placeholder="">
                                                </div>

                                                <fieldset class="form-group">
                                                    <label for="message">Mês de Referencia</label>
                                                    <br>
                                                    <select id="mes" name="mes" required class="form-control" required>
                                                        <option value="Janeiro">Janeiro</option>
                                                        <option value="Fevereiro">Fevereiro</option>
                                                        <option value="Março">Março</option>
                                                        <option value="Abril">Abril</option>
                                                        <option value="Maio">Maio</option>
                                                        <option value="Junho">Junho</option>
                                                        <option value="Julho">Julho</option>
                                                        <option value="Agosto">Agosto</option>
                                                        <option value="Setembro">Setembro</option>
                                                        <option value="Outubro">Outubro</option>
                                                        <option value="Novembro">Novembro</option>
                                                        <option value="Dezembro">Dezembro</option>
                                                    </select>
                                                </fieldset>

                                                <div class="form-group">
                                                    <label>Ano de Referencia*</label>
                                                    <input type="text" name="ano" class="form-control" required value="<?php echo date("Y"); ?>">
                                                </div>

                                                <div id="btn">
                                                    <input type="submit" class="btn btn-primary" value="Cadastrar">
                                                    <a href="ponto.php" class="btn btn-cancel">Voltar</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                    <br>
                </div>
                <br>
            </div>

<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>