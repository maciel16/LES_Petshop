<?php
require_once "../config.php";
require_once "../login.php";
$note = "";
if (isset($_GET['hs_id'])) {
    try {
        $sql = "SELECT hs.hs_id, hs.user_id, CONCAT(u.primeiro_nome,' ',u.ultimo_nome) nome, CONCAT(hs.mes,' ',hs.ano) referencia,
            hs.valor_hora, hs.qtd_horas, hs.total, hs.reg_date, hs.last_update
            FROM hora_salario hs
            INNER JOIN usuario u ON u.user_id = hs.user_id
            WHERE hs.hs_id = '$_GET[hs_id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();

        $linha = $stmt->fetch(PDO::FETCH_ASSOC);

        $hs_id = "$linha[hs_id]";
        $user_id = "$linha[user_id]";
        $nome = "$linha[nome]";
        $referencia = "$linha[referencia]";
        $valor_hora = "$linha[valor_hora]";
        $qdt_horas = "$linha[qtd_horas]";
        $total = "$linha[total]";
        $reg_date = "$linha[reg_date]";
        $last_update = "$linha[last_update]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $total = $_POST["qtd_horas"] * $valor_hora;

    if ($qdt_horas >= $_POST["qtd_horas"]) {
        $note = "*As horas não podem ser menores que as já registradas*";
    } else {
        $sql = "UPDATE hora_salario SET  qtd_horas = '$_POST[qtd_horas]', total = '$total' WHERE hs_id = $hs_id";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        if ($stmt->error) {
            echo "Error!" . $stmt->error;
            exit();
        } else {
            header("location: update.php?hs_id=$hs_id");
            exit();
        }
    }
}

$conn = null;
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">


        <div class="">
            <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                    <div class="navbar-header">
                        <button type="button" id="sidebarCollapse" class="navbar-btn">
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>

                    <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-5 col-md-5 col-sm-5">
                        <div id="" class="col-lg-12 col-md-12 col-sm-12">
                            <a href="/petshop/principal.php">| Incio</a>
                            <a href="ponto.php">> Holerite</a>
                            <a>> Alterar Holerite</a>
                        </div>
                    </div>
                </div>
            </nav>

        </div>

        <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
            <h2>Alterar Holerite</h2>

        </div>

        <div class="block col-lg-12 col-md-12 col-sm-12">
            <br>
            <div class="table">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div id="tabel">
                                <div class="card" style="margin-top:20px;">
                                    <div class="card-body">
                                        <div class="page-header">
                                            <h5 style="color:red">
                                                <?php
                                                echo $note;
                                                ?>
                                            </h5>
                                            <h2>Ficha <?php echo $hs_id; ?></h2>
                                            <h2> Referência <?php echo $referencia; ?> </h2>
                                        </div>
                                        <p>Preencha os novos dados e clique em atualizar para finalizar!</p>
                                        <form action="<?php echo $_SERVER["REQUEST_URI"] ?>" method="post">
                                            <p>Campo Obrigatório(*)</p>
                                            <div class="form-group">
                                                <label>Numero de Identificação*</label>
                                                <input type="text" name="user_id" class="form-control" readonly="true" readonly="true" required placeholder="" value="<?php echo $user_id; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label>Nome*</label>
                                                <input type="text" name="nome" class="form-control" readonly="true" required placeholder="" value="<?php echo $nome; ?>">
                                            </div>

                                            <div class="form-group">
                                                <label>Referência*</label>
                                                <input type="text" name="referencia" class="form-control" readonly="true" required placeholder="" value="<?php echo $referencia; ?>">
                                            </div>

                                            <fieldset class="form-group">
                                                <label>Valor por Hora Trabalhada em Reais(R$):*</label>
                                                <br>
                                                <input type="text" name="valor_hora" class="form-control" readonly="true" required value="<?php echo $valor_hora; ?>" />
                                            </fieldset>

                                            <fieldset class="form-group">
                                                <label>Hora Trabalhadas(R$):*</label>
                                                <br>
                                                <input type="text" name="qtd_horas" class="form-control" required value="<?php echo $qdt_horas; ?>" />
                                            </fieldset>

                                            <fieldset class="form-group">
                                                <label>Valor a Receber em Reais(R$):*</label>
                                                <br>
                                                <input type="text" name="total" class="form-control" readonly="true" required value="<?php echo $total; ?>" />
                                            </fieldset>

                                            <div class="form-group">
                                                <label>Data de Registro*</label>
                                                <input type="text" name="reg_date" class="form-control" readonly="true" required value="<?php echo $reg_date; ?>">
                                            </div>

                                            <div class="form-group">
                                                <label>Ultima Atualização*</label>
                                                <input type="text" name="last_update" class="form-control" readonly="true" required value="<?php echo $last_update; ?>">
                                            </div>
                                            <div id="btn">
                                                <input type="submit" class="btn btn-primary" value="Atualizar">
                                                <a href="ponto.php" class="btn btn-cancel">Voltar</a>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br>
                </div>
                <br>
            </div>
            <br>

            <!-- Footer Configuration, follow the link to modify-->
            <?php require_once "../components/footer.php" ?>