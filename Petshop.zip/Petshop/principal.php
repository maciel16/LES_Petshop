<?php
// Start the session
require_once "login.php";
?>

<!-- Header Configuration, follow the link to modify-->
<?php require_once "./components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "./components/sidebar.php" ?>

    <div id="content">
        <div class="">
            <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                    <div class="navbar-header">
                        <button type="button" id="sidebarCollapse" class="navbar-btn">
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>

                    <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-3 col-md-3 col-sm-3">
                        <div id="" class="col-lg-12 col-md-12 col-sm-12">
                            <a href="principal.php">| Início</a>
                        </div>
                    </div>
                </div>
            </nav>

        </div>

        <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
            <h2>Funciolidades</h2>

        </div>
        <div id="Content3" class="col-lg-12 col-md-12 col-sm-12">

            <div class="gtco-section">
                <div class="gtco-container">
                    <div class="row">

                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <a href="/petshop/usuarios/usuarios.php" class="fh5co-card-item ">
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Administrativo</h2>
                                        <p>Gerenciar Funcionários
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <a href="/petshop/ponto/ponto.php" class="fh5co-card-item ">
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Administrativo</h2>
                                        <p>Gerenciar Horas Trabalhadas
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <a href="/petshop/atendimentos/atendimentos.php" class="fh5co-card-item ">
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Atendimentos</h2>
                                        <p>Gerenciar Atendimentos
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <a href="/petshop/hist_atendimentos/hist_atendimentos.php" class="fh5co-card-item ">
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Atendimentos</h2>
                                        <p>Histórico de Atendimentos
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <a href="/petshop/clientes/clientes.php" class="fh5co-card-item ">
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Clientes</h2>
                                        <p>Gerenciar Clientes
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <a href="/petshop/animais/animais.php" class="fh5co-card-item ">
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Clientes</h2>
                                        <p>Gerenciar Animais
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <a href="/petshop/compras/compras.php" class="fh5co-card-item ">
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Compras</h2>
                                        <p>Gerenciar Compras
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <a href="/petshop/hist_compras/hist_compras.php" class="fh5co-card-item ">
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Compras</h2>
                                        <p>Histórico de Compras
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <a href="/petshop/hist_transacoes/hist_transacoes.php" class="fh5co-card-item ">
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Financeiro</h2>
                                        <p>Histórico de Transações
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <a href="/petshop/fornecedores/fornecedores.php" class="fh5co-card-item ">
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Fornecedores</h2>
                                        <p>Gerenciar Fornecedores
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <a href="/petshop/representantes/representantes.php" class="fh5co-card-item ">
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Fornecedores</h2>
                                        <p>Gerenciar Representantes
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <a href="/petshop/categorias/categorias.php" class="fh5co-card-item ">
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Produtos</h2>
                                        <p>Gerenciar Categorias
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <a href="/petshop/produtos/produtos.php" class="fh5co-card-item ">
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Produtos</h2>
                                        <p>Gerenciar Produtos
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <a href="/petshop/inventario/inventario.php" class="fh5co-card-item ">
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Produtos</h2>
                                        <p>Gerenciar Estoque
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <a href="/petshop/servicos/servicos.php" class="fh5co-card-item ">
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Serviços</h2>
                                        <p>Gerenciar Serviços
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <a href="/petshop/vendas/vendas.php" class="fh5co-card-item ">
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Vendas</h2>
                                        <p>Gerenciar Vendas
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <a href="/petshop/hist_vendas/hist_vendas.php" class="fh5co-card-item ">
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Vendas</h2>
                                        <p>Histórico de Vendas
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer Configuration, follow the link to modify-->
        <?php require_once "./components/footer.php" ?>