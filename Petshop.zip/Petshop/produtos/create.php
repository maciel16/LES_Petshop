<?php
require_once "../config.php";
require_once "../login.php";
$note = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $sql = "SELECT categoria_id
        FROM categoria
        WHERE categoria_id = '$_POST[categoria_id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();

        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $categoria_id = "$linha[categoria_id]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
    if ($categoria_id <> $_POST["categoria_id"]) {
        $note = "*Código de Identificação da Categoria não encontrado*";
    } else {
        $sql = "INSERT INTO produto (categoria_id,status)
        VALUES('$_POST[categoria_id]','Estoque')";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        if ($stmt->error) {
            echo "Error!" . $stmt->error;
            exit();
        } else {
            header("location: produtos.php");
            exit();
        }
    }
}
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-5 col-md-5 col-sm-5">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <a href="/petshop/principal.php">| Início</a>
                                <a href="produtos.php">> Produtos</a>
                                <a>> Cadastrar Produto</a>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>

            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Cadastrar Produto</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="tabel">
                                    <div class="card" style="margin-top:20px;">
                                        <div class="card-body">
                                            <div class="page-header">
                                                <h2>Cadastrar Produto</h2>
                                            </div>
                                            <p>Cadastro de Produto</p>
                                            <p>Campo Obrigatório(*)</p>
                                            <h5 style="color:red">
                                                <?php
                                                echo $note;
                                                ?>
                                            </h5>
                                            <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post">

                                                <div class="form-group">
                                                    <label>Código de Identificação da Categoria*</label>
                                                    <input type="text" name="categoria_id" class="form-control" required placeholder="">
                                                </div>

                                                <div id="btn">
                                                    <input type="submit" class="btn btn-primary" value="Cadastrar">
                                                    <a href="produtos.php" class="btn btn-cancel">Voltar</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                    <br>
                </div>
                <br>
            </div>

<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>