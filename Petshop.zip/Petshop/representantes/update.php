<?php
require_once "../config.php";
require_once "../login.php";
if (isset($_GET['representante_id'])) {

    try {
        $sql = "SELECT r.representante_id,r.primeiro_nome,r.ultimo_nome, f.razao_social empresa, r.email, r.cpf,r.telefone, r.celular, r.reg_date, r.last_update
        FROM representante r
        INNER JOIN fornecedor f ON f.fornecedor_id = r.fornecedor_id
        WHERE r.representante_id = '$_GET[representante_id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $representante_id = "$linha[representante_id]";
        $primeiro_nome ="$linha[primeiro_nome]";
        $ultimo_nome ="$linha[ultimo_nome]";
        $empresa ="$linha[empresa]";
        $email = "$linha[email]";
        $cpf = "$linha[cpf]";
        $telefone = "$linha[telefone]";
        $celular = "$linha[celular]";
        $reg_date = "$linha[reg_date]";
        $last_update = "$linha[last_update]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "UPDATE representante SET primeiro_nome = '$_POST[primeiro_nome]',ultimo_nome = '$_POST[ultimo_nome]', email = '$_POST[email]', telefone = '$_POST[telefone]',
    celular = '$_POST[celular]'
    WHERE representante_id = '$_GET[representante_id]'";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    if ($stmt->error) {
        echo "Error!" . $stmt->error;
        exit();
    } else {
        header("location: update.php?representante_id=$representante_id");
        exit();
    }
}
$conn = null;
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-11 col-md-11 col-sm-11">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <a href="/petshop/principal.php">| Início</a>
                                <a href="representantes.php">> Representantes de Forncedores</a>
                                <a>> Alterar Representantes de Forncedores</a>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>

            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Alterar Representantes</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="tabel">
                                    <div class="card" style="margin-top:20px;">
                                        <div class="card-body">
                                            <div class="page-header">
                                                <h2>Alterar</h2>
                                            </div>
                                            <p>Preencha os novos dados e clique em atualizar para finalizar a edição.</p>
                                            <form action="<?php echo $_SERVER["REQUEST_URI"] ?>" method="post">
                                                <p>Campo Obrigatório(*)</p>
                                                <div class="form-group">
                                                    <label>Código de Identificação*</label>
                                                    <input type="text" name="representante_id" class="form-control" readonly="true" required placeholder="" value="<?php echo $representante_id; ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label>Nome*</label>
                                                    <input type="text" name="primeiro_nome" class="form-control"  required placeholder="" value="<?php echo $primeiro_nome; ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label>Sobrenome*</label>
                                                    <input type="text" name="ultimo_nome" class="form-control"  required placeholder="" value="<?php echo $ultimo_nome; ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label>Razão Social*</label>
                                                    <input type="text" name="razao_social" class="form-control" readonly="true" required placeholder="" value="<?php echo $empresa; ?>">
                                                </div>

                                                <fieldset class="form-group">
                                                    <label>Email:*</label>
                                                    <br>
                                                    <input type="email" name="email" class="form-control" required value="<?php echo $email; ?>" />
                                                    <span id="email-invalid" style="visibility:hidden">
                                                        Por favor, informe um E-mail valido.</span>
                                                </fieldset>

                                                <fieldset class="form-group">
                                                    <label>CPF:*</label>
                                                    <br>
                                                    <input type="text" name="cnpj" class="form-control" readonly="true" required onkeypress="$(this).mask('00.000.000/0000-00')" value="<?php echo $cpf; ?>">
                                                </fieldset>

                                                <fieldset class="form-group">
                                                    <label>Telefone:</label>
                                                    <br>
                                                    <input type="text" name="telefone" class="form-control" onkeypress="$(this).mask('(00)0000-0000')"  value="<?php echo $telefone; ?>">
                                                </fieldset>

                                                <fieldset class="form-group">
                                                    <label>Celular:</label>
                                                    <br>
                                                    <input type="text" name="celular" class="form-control" onkeypress="$(this).mask('(00)00000-0000')" value="<?php echo $celular; ?>">
                                                </fieldset>

                                                <div class="form-group">
                                                    <label>Data de Registro*</label>
                                                    <input type="text" name="reg_date" class="form-control" readonly="true" required value="<?php echo $reg_date; ?>">
                                                </div>

                                                <div class="form-group">
                                                    <label>Ultima Atualização*</label>
                                                    <input type="text" name="last_update" class="form-control" readonly="true" required value="<?php echo $last_update; ?>">
                                                </div>
                                                <div id="btn">
                                                    <input type="submit" class="btn btn-primary" value="Atualizar">
                                                    <a href="representantes.php" class="btn btn-cancel">Voltar</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                    <br>
                </div>
                <br>
<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>