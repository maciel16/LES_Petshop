<?php
require_once "../config.php";
require_once "../login.php";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "INSERT INTO servico  (nome,descricao,departamento,preco)
    VALUES('$_POST[nome]','$_POST[descricao]','$_POST[departamento]',CAST(REPLACE(REPLACE('$_POST[preco]', '.', ''),',','.') AS DECIMAL(6,2)))";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    if ($stmt->error) {
        echo "Error!" . $stmt->error;
        exit();
    } else {
        header("location: servicos.php");
        exit();
    }
}
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-5 col-md-5 col-sm-5">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <a href="/petshop/principal.php">| Início</a>
                                <a href="servicos.php">> Serviços</a>
                                <a>> Cadastrar Serviço</a>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>

            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Cadastrar Serviços</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="tabel">
                                    <div class="card" style="margin-top:20px;">
                                        <div class="card-body">
                                            <div class="page-header">
                                                <h2>Cadastrar Serviço</h2>
                                            </div>
                                            <p>Cadastro de Serviço</p>
                                            <p>Campo Obrigatório(*)</p>
                                            <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post">


                                                <div class="form-group">
                                                    <label>Nome*</label>
                                                    <input type="text" name="nome" class="form-control" required placeholder="">
                                                </div>

                                                <div class="form-group">
                                                    <label>Descrição Completa*</label>
                                                    <input type="text" name="descricao" class="form-control" required placeholder="">
                                                </div>

                                                <fieldset class="form-group">
                                                    <label for="message">Departamento*</label>
                                                    <br>
                                                    <select id="departamento" name="departamento" required class="form-control" required>
                                                        <option value="Estética - Banho">Estética - Banho</option>
                                                        <option value="Estética - Tosa">Estética - Tosa</option>
                                                        <option value="Estoque">Estoque</option>
                                                        <option value="Vendas">Vendas</option>
                                                        <option value="Veterinária - Clinico Geral">Veterinária - Clinico Geral</option>
                                                        <option value="Veterinária - Cirurgias">Veterinária - Cirurgias</option>
                                                        <option value="Veterinária - Vacinação">Veterinária - Vacinação</option>
                                                    </select>
                                                </fieldset>

                                                <div class="form-group">
                                                    <label>Preço do serviço em Reais(R$)*</label>
                                                    <input type="text" name="preco" class="form-control" required placeholder="">
                                                </div>

                                                <div id="btn">
                                                    <input type="submit" class="btn btn-primary" value="Cadastrar">
                                                    <a href="servicos.php" class="btn btn-cancel">Voltar</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                    <br>
                </div>
                <br>
            </div>

<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>