<?php
require_once "../config.php";
require_once "../login.php";
if (isset($_GET['servico_id'])) {

    try {
        $sql = $sql = "SELECT s.servico_id, s.nome, s.descricao, s.departamento, s.preco, s.reg_date, s.last_update 
        FROM servico s
        WHERE s.servico_id ='$_GET[servico_id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $servico_id = "$linha[servico_id]";
        $nome = "$linha[nome]";
        $descricao = "$linha[descricao]";
        $departamento = "$linha[departamento]";
        $preco = "$linha[preco]";
        $reg_date = "$linha[reg_date]";
        $last_update = "$linha[last_update]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
    $conn = null;
}
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-5 col-md-5 col-sm-5">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <a href="/petshop/principal.php">| Início</a>
                                <a href="servicos.php">> Serviços</a>
                                <a>> Visualizar Serviço</a>
                            </div>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>

            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Visualizar Serviços</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="tabel">
                                    <div class="card" style="margin-top:20px;">
                                        <div class="card-body">
                                            <div class="page-header">
                                                <h1>Serviço</h1>
                                            </div>
                                            <div class="form-group">
                                                <h4>Código do Serviço</h4>
                                                <p class="form-control-static"><?php echo $servico_id; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Nome do Serviço</h4>
                                                <p class="form-control-static"><?php echo $nome; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Descricao</h4>
                                                <p class="form-control-static"><?php echo $descricao; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Departamento Responsável</h4>
                                                <p class="form-control-static"><?php echo $departamento; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Preço</h4>
                                                <p class="form-control-static"><?php echo $preco; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Data de Registro</h4>
                                                <p class="form-control-static"><?php echo $reg_date; ?></p>
                                            </div>
                                            <div class="form-group">
                                                <h4>Ultima Atualização</h4>
                                                <p class="form-control-static"><?php echo $last_update; ?></p>
                                            </div>
                                            <div id="btn">
                                                <a href="servicos.php" class="btn btn-cancel">Voltar</a>
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                    <br>
                </div>
                <br>
            </div>


<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>