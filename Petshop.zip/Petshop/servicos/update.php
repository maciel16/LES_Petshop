<?php
require_once "../config.php";
require_once "../login.php";
if (isset($_GET['servico_id'])) {

    try {
        $sql = $sql = "SELECT s.servico_id, s.nome, s.descricao, s.departamento, s.preco, s.reg_date, s.last_update 
        FROM servico s
        WHERE s.servico_id ='$_GET[servico_id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $servico_id = "$linha[servico_id]";
        $nome = "$linha[nome]";
        $descricao = "$linha[descricao]";
        $departamento = "$linha[departamento]";
        $preco = "$linha[preco]";
        $reg_date = "$linha[reg_date]";
        $last_update = "$linha[last_update]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }  
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "UPDATE servico SET nome = '$_POST[nome]', descricao = '$_POST[descricao]', preco = (CAST(REPLACE(REPLACE('$_POST[preco]', '.', ''),',','.') AS DECIMAL(6,2))) WHERE servico_id = '$_GET[servico_id]'";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    if ($stmt->error) {
        echo "Error!" . $stmt->error;
        exit();
    } else {
        header("location: update.php?servico_id=$servico_id");
        exit();
    }
    
    $conn = null;
}
$conn = null;
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-5 col-md-5 col-sm-5">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <a href="/petshop/principal.php">| Início</a>
                                <a href="servicos.php">> Serviços</a>
                                <a>> Alterar Serviço</a>
                            </div>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>

            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Alterar Serviço</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="tabel">
                                    <div class="card" style="margin-top:20px;">
                                        <div class="card-body">
                                            <div class="page-header">
                                                <h2>Alterar</h2>
                                            </div>
                                            <p>Preencha os novos dados e clique em atualizar para finalizar a edição.</p>
                                            <form action="<?php echo $_SERVER["REQUEST_URI"] ?>" method="post">
                                                <p>Campo Obrigatório(*)</p>
                                                <div class="form-group">
                                                    <label>Código do Serviços</label>
                                                    <input type="text" name="servico_id" class="form-control" readonly="true" required placeholder="" value="<?php echo $servico_id; ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label>Nome*</label>
                                                    <input type="text" name="nome" class="form-control" required placeholder="" value="<?php echo $nome; ?>">
                                                </div>

                                                <div class="form-group">
                                                    <label>Descrição Completa*</label>
                                                    <input type="text" name="descricao" class="form-control" required placeholder="" value="<?php echo $descricao; ?>">
                                                </div>

                                                <div class="form-group">
                                                    <label>Departamento*</label>
                                                    <input type="text" name="departamento" class="form-control" readonly="true" required placeholder="" value="<?php echo $departamento; ?>">
                                                </div>

                                                
                                                <div class="form-group">
                                                    <label>Preço em Reais(R$)*</label>
                                                    <input type="text" name="preco" class="form-control" required placeholder="" value="<?php echo $preco; ?>">
                                                </div>

                                                <div class="form-group">
                                                    <label>Data de Registro*</label>
                                                    <input type="text" name="reg_date" class="form-control" readonly="true" required value="<?php echo $reg_date; ?>">
                                                </div>

                                                <div class="form-group">
                                                    <label>Ultima Atualização*</label>
                                                    <input type="text" name="last_update" class="form-control" readonly="true" required value="<?php echo $last_update; ?>">
                                                </div>
                                                <div id="btn">
                                                    <input type="submit" class="btn btn-primary" value="Atualizar">
                                                    <a href="servicos.php" class="btn btn-cancel">Voltar</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                    <br>
                </div>
                <br>

<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>