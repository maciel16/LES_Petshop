<?php
require_once "../config.php";
require_once "../login.php";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "INSERT INTO usuario  (primeiro_nome,ultimo_nome,email,cpf,logradouro,complemento,cep,bairro,cidade,estado,telefone,celular,login,senha,funcao)
    VALUES('$_POST[primeiro_nome]','$_POST[ultimo_nome]','$_POST[email]','$_POST[cpf]','$_POST[logradouro]','$_POST[complemento]','$_POST[cep]','$_POST[bairro]',
    '$_POST[cidade]','$_POST[estado]','$_POST[telefone]','$_POST[celular]','$_POST[login]','$_POST[senha]','$_POST[funcao]')";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    if ($stmt->error) {
        echo "Error!" . $stmt->error;
        exit();
    } else {
        header("location: usuarios.php");
        exit();
    }
}
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-7 col-md-7 col-sm-7">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                    <a href="/petshop/principal.php">| Incio</a>
                                    <a href="usuarios.php">> Funcionários</a>
                                    <a>> Cadastrar Funcionário</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>

            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Adicionar Funcionário</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="tabel">
                                    <div class="card" style="margin-top:20px;">
                                        <div class="card-body">
                                            <div class="page-header">
                                                <h2>Adicionar Funcionário</h2>
                                            </div>
                                            <p>Cadastro de Funcionário</p>
                                            <p>Campo Obrigatório(*)</p>
                                            <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post">
                                                <div class="form-group">
                                                    <label>Nome*</label>
                                                    <input type="text" name="primeiro_nome" class="form-control" required placeholder="">
                                                </div>

                                                <div class="form-group">
                                                    <label>Sobrenome*</label>
                                                    <input type="text" name="ultimo_nome" class="form-control" required placeholder="">
                                                </div>

                                                <fieldset class="form-group">
                                                    <label>Email:*</label>
                                                    <br>
                                                    <input type="email" name="email" value="" class="form-control" required placeholder="seuemail@gmail.com" />
                                                    <span id="email-invalid" style="visibility:hidden">
                                                        Por favor, informe um E-mail valido.</span>
                                                </fieldset>

                                                <fieldset class="form-group">
                                                    <label>CPF:*</label>
                                                    <br>
                                                    <input type="text" name="cpf" class="form-control" required onkeypress="$(this).mask('000.000.000-00')" placeholder="000.000.000-00">
                                                </fieldset>

                                                <div class="form-group">
                                                    <label>Logradouro*</label>
                                                    <input type="text" name="logradouro" class="form-control" required placeholder="Rua:XXXXXXXXXXXXXXXXXX , N°XXXX">
                                                </div>

                                                <div class="form-group">
                                                    <label>Complemento</label>
                                                    <input type="text" name="complemento" class="form-control" placeholder="Bloco:XXXXXXXXXX , Apto°XXXX">
                                                </div>

                                                <fieldset class="form-group">
                                                    <label>CEP:*</label>
                                                    <br>
                                                    <input type="text" name="cep" class="form-control" required onkeypress="$(this).mask('00000-000')" placeholder="XXXXX-XXX">
                                                </fieldset>

                                                <div class="form-group">
                                                    <label>Bairro*</label>
                                                    <input type="text" name="bairro" class="form-control" required placeholder="">
                                                </div>

                                                <fieldset class="form-group">
                                                    <label for="message">Cidade</label>
                                                    <br>
                                                    <select id="cidade" name="cidade" required class="form-control" required>
                                                        <option value="Americana">Americana</option>
                                                        <option value="Nova Odessa">Nova Odessa</option>
                                                        <option value="Santa Barbara d'Oeste">Santa Barbara d'Oeste</option>
                                                        <option value="Sumaré">Sumaré</option>
                                                    </select>
                                                </fieldset>

                                                <div class="form-group">
                                                    <label>Estado*</label>
                                                    <input type="text" name="estado" class="form-control" readonly="true" required value="São Paulo - SP" placeholder="São Paulo - SP">
                                                </div>

                                                <fieldset class="form-group">
                                                    <label>Telefone:</label>
                                                    <br>
                                                    <input type="text" name="telefone" class="form-control" onkeypress="$(this).mask('(00)0000-0000')" placeholder="(XX)XXXX-XXXX">
                                                </fieldset>

                                                <fieldset class="form-group">
                                                    <label>Celular:*</label>
                                                    <br>
                                                    <input type="text" name="celular" class="form-control" required onkeypress="$(this).mask('(00)00000-0000')" placeholder="(XX)XXXXX-XXXX">
                                                </fieldset>

                                                <fieldset class="form-group">
                                                    <label>Login:*</label>
                                                    <br>
                                                    <input type="text" name="login" class="form-control" required>
                                                </fieldset>

                                                <fieldset class="form-group">
                                                    <label>Senha:*</label>
                                                    <br>
                                                    <input type="password" name="senha" class="form-control" required>
                                                </fieldset>

                                                <fieldset class="form-group">
                                                    <label for="message">Função*</label>
                                                    <br>
                                                    <select id="funcao" name="funcao" required class="form-control" required>
                                                        <option value="Administrador">Administrador</option>
                                                        <option value="Administrativo">Administrativo</option>
                                                        <option value="Financeiro">Financeiro</option>
                                                        <option value="Caixa">Caixa</option>
                                                        <option value="Compras">Compras</option>
                                                        <option value="Estética - Banho">Estética - Banho</option>
                                                        <option value="Estética - Tosa">Estética - Tosa</option>
                                                        <option value="Estoque">Estoque</option>
                                                        <option value="Vendas">Vendas</option>
                                                        <option value="Veterinária - Clinico Geral">Veterinária - Clinico Geral</option>
                                                        <option value="Veterinária - Cirurgias">Veterinária - Cirurgias</option>
                                                        <option value="Veterinária - Vacinação">Veterinária - Vacinação</option>
                                                    </select>
                                                </fieldset>

                                                <div id="btn">
                                                    <input type="submit" class="btn btn-primary" value="Cadastrar">
                                                    <a href="usuarios.php" class="btn btn-cancel">Voltar</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                    <br>
                </div>
                <br>
            </div>


<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>