<?php
require_once "../config.php";
require_once "../login.php";
if (isset($_GET['user_id'])) {
    try {
        $sql = "SELECT u.user_id, u.primeiro_nome, u.ultimo_nome, u.email, u.cpf, u.logradouro, u.complemento, u.cep,
        u.bairro, u.cidade, u.estado, u.telefone, u.celular, u.funcao, u.login,u.senha, u.reg_date, u.last_update
            FROM usuario u
            WHERE u.user_id = '$_GET[user_id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $user_id = $row["user_id"];
        $primeiro_nome = $row["primeiro_nome"];
        $ultimo_nome = $row["ultimo_nome"];
        $email = $row["email"];
        $cpf = $row["cpf"];
        $logradouro = $row["logradouro"];
        $complemento = $row["complemento"];
        $cep = $row["cep"];
        $bairro = $row["bairro"];
        $cidade = $row["cidade"];
        $estado = $row["estado"];
        $telefone = $row["telefone"];
        $celular = $row["celular"];
        $funcao = $row["funcao"];
        $login = $row["login"];
        $senha = $row["senha"];
        $reg_date = $row["reg_date"];
        $last_update = $row["last_update"];;
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "UPDATE usuario SET primeiro_nome = '$_POST[primeiro_nome]', ultimo_nome = '$_POST[ultimo_nome]', email = '$_POST[email]', logradouro = '$_POST[logradouro]',
    complemento = '$_POST[complemento]', cep = '$_POST[cep]', bairro = '$_POST[bairro]', cidade = '$_POST[cidade]', telefone = '$_POST[telefone]',
    celular = '$_POST[celular]', login = '$_POST[login]', senha = '$_POST[senha]', funcao = '$_POST[funcao]' WHERE user_id = '$_POST[user_id]'";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    if ($stmt->error) {
        echo "Error!" . $stmt->error;
        exit();
    } else {
        header("location: update.php?user_id=$user_id");
        exit();
    }
}
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-6 col-md-6 col-sm-6">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                    <a href="/petshop/principal.php">| Início</a>
                                    <a href="usuarios.php">> Funcionários</a>
                                    <a>> Alterar Funcionário</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>

            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Alterar Funcionário</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="tabel">
                                    <div class="card" style="margin-top:20px;">
                                        <div class="card-body">
                                            <div class="page-header">
                                                <h2>Alterar</h2>
                                            </div>
                                            <p>Preencha os novos dados e clique em atualizar para finalizar a edição.</p>
                                            <form action="<?php echo $_SERVER["REQUEST_URI"] ?>" method="post">
                                                <p>Campo Obrigatório(*)</p>
                                                <div class="form-group">
                                                    <label>Código de Identificação*</label>
                                                    <input type="text" name="user_id" class="form-control" readonly="true" required placeholder="" value="<?php echo $_GET['user_id']; ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label>Nome*</label>
                                                    <input type="text" name="primeiro_nome" class="form-control" required placeholder="" value="<?php echo $primeiro_nome; ?>">
                                                </div>

                                                <div class="form-group">
                                                    <label>Sobrenome*</label>
                                                    <input type="text" name="ultimo_nome" class="form-control" required placeholder="" value="<?php echo $ultimo_nome; ?>">
                                                </div>

                                                <fieldset class="form-group">
                                                    <label>Email:*</label>
                                                    <br>
                                                    <input type="email" name="email" class="form-control" required value="<?php echo $email; ?>" />
                                                    <span id="email-invalid" style="visibility:hidden">
                                                        Por favor, informe um E-mail valido.</span>
                                                </fieldset>

                                                <fieldset class="form-group">
                                                    <label>CPF:*</label>
                                                    <br>
                                                    <input type="text" name="cpf" class="form-control" readonly="true" required onkeypress="$(this).mask('000.000.000-00')" placeholder="000.000.000-00" value="<?php echo $cpf; ?>">
                                                </fieldset>

                                                <div class="form-group">
                                                    <label>Logradouro*</label>
                                                    <input type="text" name="logradouro" class="form-control" required placeholder="Rua:XXXXXXXXXXXXXXXXXX , N°XXXX" value="<?php echo $logradouro; ?>">
                                                </div>

                                                <div class="form-group">
                                                    <label>Complemento</label>
                                                    <input type="text" name="complemento" class="form-control" placeholder="Bloco:XXXXXXXXXX , Apto°XXXX" value="<?php echo $complemento; ?>">
                                                </div>

                                                <fieldset class="form-group">
                                                    <label>CEP:*</label>
                                                    <br>
                                                    <input type="text" name="cep" class="form-control" required onkeypress="$(this).mask('00000-000')" placeholder="XXXXX-XXX" value="<?php echo $cep; ?>">
                                                </fieldset>

                                                <div class="form-group">
                                                    <label>Bairro*</label>
                                                    <input type="text" name="bairro" class="form-control" required value="<?php echo $bairro; ?>">
                                                </div>

                                                <fieldset class="form-group">
                                                    <label for="message">Cidade</label>
                                                    <br>
                                                    <select id="cidade" name="cidade" required class="form-control" required value="<?php echo $cidade; ?>">
                                                        <option value="Americana">Americana</option>
                                                        <option value="Nova Odessa">Nova Odessa</option>
                                                        <option value="Santa Barbara d'Oeste">Santa Barbara d'Oeste</option>
                                                        <option value="Sumaré">Sumaré</option>
                                                    </select>
                                                </fieldset>

                                                <div class="form-group">
                                                    <label>Estado*</label>
                                                    <input type="text" name="estado" class="form-control" readonly="true" required value="<?php echo $estado; ?>">
                                                </div>

                                                <fieldset class="form-group">
                                                    <label>Telefone:</label>
                                                    <br>
                                                    <input type="text" name="telefone" class="form-control" onkeypress="$(this).mask('(00)0000-0000')" placeholder="(XX)XXXX-XXXX" value="<?php echo $telefone; ?>">
                                                </fieldset>

                                                <fieldset class="form-group">
                                                    <label>Celular:*</label>
                                                    <br>
                                                    <input type="text" name="celular" class="form-control" required onkeypress="$(this).mask('(00)00000-0000')" placeholder="(XX)XXXXX-XXXX" value="<?php echo $celular; ?>">
                                                </fieldset>

                                                <fieldset class="form-group">
                                                    <label>Login:*</label>
                                                    <br>
                                                    <input type="text" name="login" class="form-control" required value="<?php echo $login; ?>">
                                                </fieldset>

                                                <fieldset class="form-group">
                                                    <label>Senha:*</label>
                                                    <br>
                                                    <input type="password" name="senha" class="form-control" required value="<?php echo $senha; ?>">
                                                </fieldset>

                                                <fieldset class="form-group">
                                                    <label for="message">Função*</label>
                                                    <br>
                                                    <select id="funcao" name="funcao" required class="form-control" required>
                                                        <option selected="<?php $funcao; ?>"><?php echo $funcao; ?></option>
                                                        <option value="Administrador">Administrador</option>
                                                        <option value="Administrativo">Administrativo</option>
                                                        <option value="Financeiro">Financeiro</option>
                                                        <option value="Caixa">Caixa</option>
                                                        <option value="Compras">Compras</option>
                                                        <option value="Estética - Banho">Estética - Banho</option>
                                                        <option value="Estética - Tosa">Estética - Tosa</option>
                                                        <option value="Estoque">Estoque</option>
                                                        <option value="Vendas">Vendas</option>
                                                        <option value="Veterinária - Clinico Geral">Veterinária - Clinico Geral</option>
                                                        <option value="Veterinária - Cirurgias">Veterinária - Cirurgias</option>
                                                        <option value="Veterinária - Vacinação">Veterinária - Vacinação</option>
                                                    </select>
                                                </fieldset>

                                                <div class="form-group">
                                                    <label>Data de Registro*</label>
                                                    <input type="text" name="reg_date" class="form-control" readonly="true" required value="<?php echo $reg_date; ?>">
                                                </div>

                                                <div class="form-group">
                                                    <label>Ultima Atualização*</label>
                                                    <input type="text" name="last_update" class="form-control" readonly="true" required value="<?php echo $last_update; ?>">
                                                </div>
                                                <div id="btn">
                                                    <input type="submit" class="btn btn-primary" value="Atualizar">
                                                    <a href="usuarios.php" class="btn btn-cancel">Voltar</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                    <br>
                </div>
                <br>

<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>