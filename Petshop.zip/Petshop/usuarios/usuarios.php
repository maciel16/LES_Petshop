<?php
require_once "../config.php";
require_once "../login.php";
try {
    $sql = "SELECT u.user_id, u.primeiro_nome, u.ultimo_nome , u.funcao
    FROM usuario u;";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    try {
        $sql = "SELECT u.user_id, u.primeiro_nome, u.ultimo_nome, u.funcao
        FROM usuario u
        WHERE u.user_id LIKE'%$_POST[busca]%'
        OR  u.primeiro_nome LIKE '%$_POST[busca]%'
        OR  u.ultimo_nome LIKE '%$_POST[busca]%'
        OR  u.funcao LIKE '%$_POST[busca]%'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-4 col-md-4 col-sm-4">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                    <a href="/petshop/principal.php">| Início</a>
                                    <a>> Funcionários</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>
            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Gerenciamento de Funcionários</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table col-lg-12 col-md-12 col-sm-12">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div id="tabel">
                                <div class="card" style="margin-top: 20px;margin-bottom: 20px;">
                                    <div class="card-body">
                                        <div class="pull-left col-lg-3 col-md-3 col-sm-3">
                                            <a href="create.php" class="btn btn-success ">Adicionar Novo Usuário</a>
                                        </div>
                                        <div class="pull-right col-lg-2 col-md-2 col-sm-2">
                                            <h4>Buscar</h4>
                                        </div>
                                        <div class="pull-left col-lg-7 col-md-7 col-sm-7">
                                            <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post">
                                                <div class="form-group col-lg-7 col-md-8 col-sm-7">
                                                    <input type="text" name="busca" class="form-control" required placeholder="">
                                                </div>
                                                <div id="btn" class="col-lg-2 col-md-2 col-sm-2">
                                                    <input type="submit" class="btn btn-primary" value="Pesquisar">
                                                </div>
                                                <div id="btn" class="col-lg-2 col-md-2 col-sm-2">
                                                    <a href="usuarios.php" class="btn btn-warning">Todos</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                if ($stmt->rowCount()) {
                                    echo "<table class='table table-bordered table-striped'>";
                                    echo "<thead>";
                                    echo "<tr>";
                                    echo "<th># </th>";
                                    echo "<th>Nome </th>";
                                    echo "<th>Sobrenome</th>";
                                    echo "<th>Função</th>";
                                    echo "<th>Action</th>";
                                    echo "</tr>";
                                    echo "</thead>";
                                    echo "<tbody>";
                                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                        echo "<tr>";
                                        echo "<td>" . $row['user_id'] . "</td>";
                                        echo "<td>" . $row['primeiro_nome'] . "</td>";
                                        echo "<td>" . $row['ultimo_nome'] . "</td>";
                                        echo "<td>" . $row['funcao'] . "</td>";
                                        echo "<td>";
                                        echo "<a href='read.php?user_id=" . $row['user_id'] . "' class='btn btn-primary'>Visualizar</a>&nbsp;&nbsp;&nbsp;";
                                        echo "<a href='update.php?user_id=" . $row['user_id'] . "' class='btn btn-info'>Editar</a>&nbsp;&nbsp;&nbsp;";
                                        echo "<a href='delete.php?user_id=" . $row['user_id'] . "' class='btn btn-cancel'>Remover</a>";
                                        echo "</td>";
                                        echo "</tr>";
                                    }
                                    echo "</tbody>";
                                    echo "</table>";
                                } else {
                                    echo "<p class='lead'><em>No records were found.</em></p>";
                                }
                                $link->close();
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>