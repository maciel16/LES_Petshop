<?php
require_once "../config.php";
require_once "../login.php";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "INSERT INTO venda  (cliente_id,descricao,status,valor)
    VALUES('$_POST[cliente_id]','$_POST[descricao]','Em Andamento','0')";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    if ($stmt->error) {
        echo "Error!" . $stmt->error;
        exit();
    } else {

        header("location: vendas.php");
        exit();
    }
}
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-5 col-md-5 col-sm-5">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <a href="/petshop/principal.php">| Início</a>
                                <a href="vendas.php">> Vendas</a>
                                <a>> Nova Venda</a>
                            </div>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>

            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Adicionar Venda</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="tabel">
                                    <div class="card" style="margin-top:20px;">
                                        <div class="card-body">
                                            <div class="page-header">
                                                <h2>Adicionar Venda</h2>
                                            </div>
                                            <p>Cadastro de Venda</p>
                                            <p>Obrigatório(*)</p>
                                            <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post">

                                                <div class="form-group">
                                                    <label>Código do Cliente*</label>
                                                    <input type="text" name="cliente_id" class="form-control" required placeholder="">
                                                </div>

                                                <div class="form-group">
                                                    <label>Descrição*</label>
                                                    <input type="text" name="descricao" class="form-control" required placeholder="">
                                                </div>

                                                <div id="btn">
                                                    <input type="submit" class="btn btn-primary" value="Cadastrar">
                                                    <a href="vendas.php" class="btn btn-cancel">Voltar</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                    <br>
                </div>
                <br>
            </div>

<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>