<?php
require_once "../config.php";
require_once "../login.php";
if (isset($_GET['venda_id'])) {

    try {
        $sql = "SELECT v.venda_id, v.cliente_id,CONCAT(c.primeiro_nome,' ',c.ultimo_nome) cliente, v.valor, v.descricao, v.reg_date, v.last_update 
        FROM venda v
        INNER JOIN cliente c ON c.cliente_id = v.cliente_id;
        WHERE v.venda_id = '$_GET[venda_id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $venda_id = "$linha[venda_id]";
        $cliente_id = "$linha[cliente_id]";
        $nome = "$linha[cliente]";
        $descricao = "$linha[descricao]";
        $valor = "$linha[valor]";
        $reg_date = "$linha[reg_date]";
        $last_update = "$linha[last_update]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "UPDATE venda SET venda.status = 'Finalizada' WHERE venda_id = '$_GET[venda_id]'";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    if ($stmt->error) {
        echo "Error!" . $stmt->error;
        exit();
    } else {
        header("location: vendas.php?");
        exit();
    }
}
$conn = null;
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-5 col-md-5 col-sm-5">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                    <a href="/petshop/principal.php">| Início</a>
                                    <a href="vendas.php">> Vendas</a>
                                    <a>> Finalizar Venda</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>

            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Visualizar Venda</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="tabel">
                                    <div class="card" style="margin-top:20px;">
                                        <div class="card-body">
                                            <div class="page-header">
                                                <h1>Informações da Vendas</h1>
                                            </div>
                                            <form action="<?php echo $_SERVER["REQUEST_URI"] ?>" method="post">
                                                <div class="form-group">
                                                    <h4>Cógido da Venda</h4>
                                                    <p class="form-control-static"><?php echo $venda_id; ?></p>
                                                </div>

                                                <div class="form-group">
                                                    <h4>Código de Identificação do Cliente</h4>
                                                    <p class="form-control-static"><?php echo $cliente_id; ?></p>
                                                </div>

                                                <div class="form-group">
                                                    <h4>Nome</h4>
                                                    <p class="form-control-static"><?php echo $nome; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Descrição da Venda</h4>
                                                    <p class="form-control-static"><?php echo $descricao; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Valor dos Total da Venda</h4>
                                                    <p class="form-control-static">R$<?php echo $valor; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Data de Registro</h4>
                                                    <p class="form-control-static"><?php echo $reg_date; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Ultima Atualização</h4>
                                                    <p class="form-control-static"><?php echo $last_update; ?></p>
                                                </div>
                                                <div id="btn" class="col-lg-12 col-md-12 col-sm-12">
                                                    <input type="submit" class="btn btn-primary" value="Finalizar">
                                                    <a href="vendas.php?" class="btn btn-cancel">Voltar</a>&nbsp;&nbsp;&nbsp;
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                    <br>
                </div>
                <br>
            </div>

<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>