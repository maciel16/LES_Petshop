<?php
require_once "../config.php";
require_once "../login.php";
(isset($_GET['venda_id']));
$_SESSION["venda_id"] = $_GET['venda_id'];
try {
    $sql = "SELECT vp.id,vp.produto_id, ca.descricao ,vp.valor, vp.reg_date
    FROM venda_produto vp
    INNER JOIN venda v ON v.venda_id = vp.venda_id
    INNER JOIN produto p ON p.produto_id = vp.produto_id
    INNER JOIN categoria ca ON ca.categoria_id = p.categoria_id
    WHERE vp.venda_id = '$_GET[venda_id]'";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-4 col-md-4 col-sm-4">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <a href="/petshop/vendas/vendas.php" >| Vendas</a>
                                <a >> Carrinho de Venda</a>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>
            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Carrinho da Venda</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table col-lg-12 col-md-12 col-sm-12">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div id="tabel">
                                <div class="card" style="margin-top: 20px;margin-bottom: 20px;">
                                    <div class="card-body">
                                        <div class="pull-left col-lg-3 col-md-3 col-sm-3">
                                            <?php
                                            echo "<a href='venda_produtos_create.php?venda_id=" . $_GET['venda_id'] . "' class='btn btn-success'>Adicionar Produto</a>&nbsp;&nbsp;&nbsp;";
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                if ($stmt->rowCount()) {
                                    echo "<table class='table table-bordered table-striped'>";
                                    echo "<thead>";
                                    echo "<tr>";
                                    echo "<th># </th>";
                                    echo "<th>Código do Produto</th>";
                                    echo "<th>Descrição </th>";
                                    echo "<th>Preço</th>";
                                    echo "<th>Data</th>";
                                    echo "<th>Action</th>";
                                    echo "</tr>";
                                    echo "</thead>";
                                    echo "<tbody>";
                                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                        echo "<tr>";
                                        echo "<td>" . $row['id'] . "</td>";
                                        echo "<td>" . $row['produto_id'] . "</td>";
                                        echo "<td>" . $row['descricao'] . "</td>";
                                        echo "<td>" . $row['valor'] . "</td>";
                                        echo "<td>" . $row['reg_date'] . "</td>";
                                        echo "<td>";
                                        echo "<a href='venda_produtos_read.php?id=" . $row['id'] . "' class='btn btn-primary'>Visualizar</a>&nbsp;&nbsp;&nbsp;";
                                        echo "<a href='venda_produtos_delete.php?id=" . $row['id'] . "' class='btn btn-cancel'>Remover</a>&nbsp;&nbsp;&nbsp;";
                                        echo "</td>";
                                        echo "</tr>";
                                    }
                                    echo "</tbody>";
                                    echo "</table>";
                                    // Free result set
                                } else {
                                    echo "<p class='lead'><em>No records were found.</em></p>";
                                }
                                $link->close();
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>