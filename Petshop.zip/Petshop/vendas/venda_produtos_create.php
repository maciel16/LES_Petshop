<?php
require_once "../config.php";
require_once "../login.php";

$note = "";
(isset($_SESSION['venda_id']));
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $sql = "SELECT produto_id
                FROM produto
                WHERE produto_id = '$_POST[produto_id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $produto_id = "$linha[produto_id]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
    if ($produto_id <> "$_POST[produto_id]") {
        $note = "*O Código do produto não foi encontrado!*";
    } else {
        $sql = "SELECT ca.valor_unitario
                FROM produto p
                INNER JOIN categoria ca ON ca.categoria_id = p.categoria_id
                WHERE p.produto_id = $_POST[produto_id]";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $valor_unitario = "$linha[valor_unitario]";
        if ($stmt->error) {
            echo "Error!" . $stmt->error;
            exit();
        } else {
            $sql2 = "INSERT INTO venda_produto(produto_id,venda_id,valor)
        VALUES('$_POST[produto_id]','$_POST[venda_id]','$valor_unitario')";
            $stmt2 = $conn->prepare($sql2);
            $stmt2->execute();
            if ($stmt2->error) {
                echo "Error!" . $stmt2->error;
                exit();
            } else {
                header("location: venda_produtos.php?venda_id=$_POST[venda_id]");

                exit();
            }
        }
    }
}
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-8 col-md-8 col-sm-8">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <a href="/petshop/vendas/vendas.php">| Vendas</a>
                                <a>> Carrinho de Venda</a>
                                <a>> Adicionar Produto ao Carrinho</a>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>

            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Adicionar Produto Adquirido</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="tabel">
                                    <div class="card" style="margin-top:20px;">
                                        <div class="card-body">
                                            <div class="page-header">
                                                <h2>Adicionar Produto Adquirido</h2>
                                            </div>
                                            <p>Cadastro de Produto Adquirido</p>
                                            <p>Campo Obrigatório(*)</p>
                                            <h5 style="color:red">
                                                    <?php
                                                    echo $note;
                                                    ?>
                                                </h5>
                                            <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post">

                                                <div class="form-group">
                                                    <label>Código da Venda*</label>
                                                    <input type="text" name="venda_id" readonly="true" class="form-control" value="<?php echo $_SESSION['venda_id']; ?>" required placeholder="">
                                                </div>

                                                <div class="form-group">
                                                    <label>Código do produto*</label>
                                                    <input type="text" name="produto_id" class="form-control" required placeholder="">
                                                </div>

                                                <div id="btn">
                                                    <input type="submit" class="btn btn-primary" value="Cadastrar">
                                                    <?php
                                                    echo "<a href='venda_produtos.php?venda_id=" . $_SESSION['venda_id'] . "' class='btn btn-cancel'>Voltar</a>&nbsp;&nbsp;&nbsp;";
                                                    ?>
                                                </div>
                                            </form>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                    <br>
                </div>
                <br>
            </div>


<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>