<?php
require_once "../config.php";
require_once "../login.php";
if (isset($_GET['id'])) {
    try {
        $sql = "SELECT vp.id,vp.venda_id, vp.produto_id, ca.descricao ,vp.valor, vp.reg_date
        FROM venda_produto vp
        INNER JOIN venda v ON v.venda_id = vp.venda_id
        INNER JOIN produto p ON p.produto_id = vp.produto_id
        INNER JOIN categoria ca ON ca.categoria_id = p.categoria_id
        WHERE vp.id = '$_GET[id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $venda_id = "$linha[venda_id]";
        $id = "$linha[id]";
        $produto_id = "$linha[produto_id]";
        $descricao = "$linha[descricao]";
        $preco = "$linha[valor]";
        $reg_date = "$linha[reg_date]";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }


    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $sql = "DELETE 
            FROM venda_produto 
            WHERE id = '$_GET[id]'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        if ($stmt->error) {
            echo "Error!" . $stmt->error;
            exit();
        } else {
            header("location: venda_produtos.php?venda_id=" . $linha['venda_id'] . "");
            exit();
        }
        $conn = null;
    }
}
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-8 col-md-8 col-sm-8">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <a href="/petshop/vendas/vendas.php">| Vendas</a>
                                <a>> Carrinho de Venda</a>
                                <a>> Remover Produto no Carrinho</a>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>

            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Remover Atendimento</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="tabel">
                                    <div class="card" style="margin-top:20px;">
                                        <div class="card-body">
                                            <div class="page-header">
                                                <h1>Informações da Venda</h1>
                                            </div>
                                            <form action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post">
                                                <div class="form-group">
                                                    <h4>Cógido do Produto</h4>
                                                    <p class="form-control-static"><?php echo $produto_id; ?></p>
                                                </div>

                                                <div class="form-group">
                                                    <h4>Cógido da Venda</h4>
                                                    <p class="form-control-static"><?php echo $venda_id; ?></p>
                                                </div>

                                                <div class="form-group">
                                                    <h4>Descrição</h4>
                                                    <p class="form-control-static"><?php echo $descricao; ?></p>
                                                </div>

                                                <div class="form-group">
                                                    <h4>Preço</h4>
                                                    <p class="form-control-static"><?php echo $preco; ?></p>
                                                </div>
                                                <div class="form-group">
                                                    <h4>Data</h4>
                                                    <p class="form-control-static"><?php echo $reg_date; ?></p>
                                                </div>
                                                <div id="btn" class="col-lg-12 col-md-12 col-sm-12">
                                                    <input type="submit" class="btn btn-primary" value="Remover">
                                                    <?php
                                                    echo "<a href='venda_produtos.php?venda_id=" . $venda_id . "' class='btn btn-cancel'>Voltar</a>&nbsp;&nbsp;&nbsp;";
                                                    ?>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                    <br>
                </div>
                <br>
            </div>


<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>