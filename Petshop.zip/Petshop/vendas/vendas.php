<?php
require_once "../config.php";
require_once "../login.php";
try {
    $sql = "SELECT v.venda_id, v.cliente_id,CONCAT(c.primeiro_nome,' ',c.ultimo_nome) cliente, v.valor
    FROM venda v
    INNER JOIN cliente c ON c.cliente_id = v.cliente_id
    WHERE v.status ='Em Andamento'";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    try {
        $sql = "SELECT v.venda_id, v.cliente_id,CONCAT(c.primeiro_nome,' ',c.ultimo_nome) cliente, v.valor
        FROM venda v
        INNER JOIN cliente c ON c.cliente_id = v.cliente_id;
        WHERE v.venda_id LIKE'%$_POST[busca]%'
        OR  c.primeiro_nome LIKE '%$_POST[busca]%'
        OR  c.ultimo_nome LIKE '%$_POST[busca]%'
        OR  v.cliente_id LIKE '%$_POST[busca]%'
        OR  v.valor LIKE '%$_POST[busca]%'
        AND v.status ='Em Andamento";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
<!-- Header Configuration, follow the link to modify-->
<?php require_once "../components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "../components/sidebar.php" ?>

    <div id="content">

            <div class="">
                <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                    <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-3 col-md-3 col-sm-3">
                            <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                <div id="" class="col-lg-12 col-md-12 col-sm-12">
                                    <a href="/petshop/principal.php">| Incio</a>
                                    <a>> Vendas</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </nav>

            </div>
            <div id="Content2" class="col-lg-12 col-md-12 col-sm-12">
                <h2>Vendas em Andamento</h2>

            </div>

            <div class="block col-lg-12 col-md-12 col-sm-12">
                <br>
                <div class="table col-lg-12 col-md-12 col-sm-12">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div id="tabel">
                                <div class="card" style="margin-top: 20px;margin-bottom: 20px;">
                                    <div class="card-body">
                                        <div class="pull-left col-lg-3 col-md-3 col-sm-3">
                                            <a href="create.php" class="btn btn-success ">Nova Venda</a>
                                        </div>
                                        <div class="pull-right col-lg-2 col-md-2 col-sm-2">
                                            <h4>Buscar</h4>
                                        </div>
                                        <div class="pull-left col-lg-7 col-md-7 col-sm-7">
                                            <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post">
                                                <div class="form-group col-lg-7 col-md-8 col-sm-7">
                                                    <input type="text" name="busca" class="form-control" required placeholder="">
                                                </div>
                                                <div id="btn" class="col-lg-2 col-md-2 col-sm-2">
                                                    <input type="submit" class="btn btn-primary" value="Pesquisar">
                                                </div>
                                                <div id="btn" class="col-lg-2 col-md-2 col-sm-2">
                                                    <a href="user.php" class="btn btn-warning">Todos</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                if ($stmt->rowCount()) {
                                    echo "<table class='table table-bordered table-striped'>";
                                    echo "<thead>";
                                    echo "<tr>";
                                    echo "<th># </th>";
                                    echo "<th>Código do Cliente</th>";
                                    echo "<th>Nome </th>";
                                    echo "<th>Valor</th>";
                                    echo "<th>Action</th>";
                                    echo "</tr>";
                                    echo "</thead>";
                                    echo "<tbody>";
                                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                        echo "<tr>";
                                        echo "<td>" . $row['venda_id'] . "</td>";
                                        echo "<td>" . $row['cliente_id'] . "</td>";
                                        echo "<td>" . $row['cliente'] . "</td>";
                                        echo "<td>" . $row['valor'] . "</td>";
                                        echo "<td>";
                                        echo "<a href='read.php?venda_id=" . $row['venda_id'] . "' class='btn btn-primary'>Visualizar</a>&nbsp;&nbsp;&nbsp;";
                                        echo "<a href='venda_produtos.php?venda_id=" . $row['venda_id'] . "' class='btn btn-info'>Produtos Adquiridos</a>&nbsp;&nbsp;&nbsp;";
                                        echo "<a href='done.php?venda_id=" . $row['venda_id'] . "' class='btn btn-cancel'>Finalizar Venda</a>";
                                        echo "</td>";
                                        echo "</tr>";
                                    }
                                    echo "</tbody>";
                                    echo "</table>";
                                    // Free result set
                                } else {
                                    echo "<p class='lead'><em>No records were found.</em></p>";
                                }
                                $link->close();
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


<!-- Footer Configuration, follow the link to modify-->
<?php require_once "../components/footer.php" ?>